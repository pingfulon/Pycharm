#! /usr/python/bin
# -*- coding=UTF-8 -*-

import unittest
from Public import *
import connect
from config import *
import json
import time
import re

class SpeechRecognizerRecognizeTextRequest(unittest.TestCase):

    def setUp(self):
        self.verificationErrors = []
        self.Pheader = Pheader
        self.conn = connect.conn
        self.accept_next_alert = True

    def test_RecognizeTextRequest(self):
        #******************************************修改用户信息******************************************************
        u"""验证ProcTextRequest"""

        body = bodydata("SpeechRecognizer","ProcTextRequest","EventText")
        #print body
        testbody = httpdatatext(body)
        print testbody
        streamid1 = self.conn.request(post,eventspath,body=testbody,headers=self.Pheader)

        print streamid1
        response = self.conn.get_response(stream_id=streamid1)
        h = response.headers
        #print h
        status = response.status
        print status
        assert status == 200
        content =response.read()
        print content
        r4,r1,r2,r3=getresponsetext(content)

        SetMute = json.loads(r1)
        self.assertEqual(SetMute["directive"]["header"]["namespace"], "Speaker")
        self.assertEqual(SetMute["directive"]["header"]["name"], "SetMute")
        self.assertNotEqual(SetMute["directive"]["header"]["messageId"], "1")
        self.assertEqual(SetMute["directive"]["header"]["dialogRequestId"],"518e1f56-0857-49a7-a5d0-528277751b99")
        #print SetMute["directive"]["payload"]["mute"]
        if SetMute["directive"]["payload"]["mute"] in [False,True]:
            mute = True
        else:
            mute = False
        self.assertTrue(mute)
        #
        Speak = json.loads(r2)
        self.assertEqual(Speak["directive"]["header"]["namespace"], "SpeechSynthesizer")
        self.assertEqual(Speak["directive"]["header"]["name"], "Speak")
        self.assertNotEqual(Speak["directive"]["header"]["messageId"], "1")
        self.assertEqual(Speak["directive"]["header"]["dialogRequestId"],"518e1f56-0857-49a7-a5d0-528277751b99")
        self.assertEqual(Speak["directive"]["payload"]["format"], "AUDIO_MPEG")
        u = re.compile(r"(.*):(\w+)").findall(Speak["directive"]["payload"]["url"])
        url = u[0][0] + ":"
        self.assertEqual(url, "cid:")
        #print r3
        MetaData = json.loads(r3)
        self.assertEqual(MetaData["directive"]["header"]["namespace"], "TemplateRuntime")
        self.assertEqual(MetaData["directive"]["header"]["name"], "MetaData")
        self.assertNotEqual(MetaData["directive"]["header"]["messageId"], "1")
        self.assertEqual(MetaData["directive"]["header"]["dialogRequestId"],"518e1f56-0857-49a7-a5d0-528277751b99")
        if MetaData["directive"]["payload"]["modelName"] in modelname:
            MN= True
        else:
            MN = False
        self.assertTrue(MN)
        #print "condsd %s" %content


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        self.conn.close()

if __name__ == "__main__":
    unittest.main()





