#! /usr/python/bin
# -*- coding=UTF-8 -*-

import unittest
from Public import *
import connect
from config import *
import json

class SpeechRecognizerRecognize(unittest.TestCase):

    def setUp(self):
        self.verificationErrors = []
        self.Pheader = Pheader
        self.conn = connect.conn
        self.streamid = connect.streamid
        self.accept_next_alert = True

    def test_Recognize(self):
        #******************************************修改用户信息******************************************************
        u"""验证半关闭"""
        body = bodydata("SpeechRecognizer","Recognize","Event")
        testbody=httpdatabinary(str(body),"./audiofile/chengyu.wav")
        #print testbody
        ebody = bodydata("SpeechRecognizer","ProcTextRequest","EventExit")
        exitbody = httpdatatext(str(ebody))

        streamid1 = self.conn.request(post,eventspath,body=testbody,headers=self.Pheader)

        response = self.conn.get_response(stream_id=streamid1)

        status = response.status
        #print "sat %s" %status
        assert status == 200
        res = response.read()
        print res
        r1,r2,r3,r4=getresponsebin(res)
        #print r1
        StopCapture= json.loads(r1)
        self.assertEqual(StopCapture["directive"]["header"]["name"],"StopCapture")
        self.assertEqual(StopCapture["directive"]["header"]["namespace"],"SpeechRecognizer")
        self.assertNotEqual(StopCapture["directive"]["header"]["messageId"],"1")
        #self.assertEqual(StopCapture["directive"]["header"]["dialogRequestId"],"234qazwsx")
        #print r2
        SetMute = json.loads(r2)
        self.assertEqual(SetMute["directive"]["header"]["namespace"], "Speaker")
        self.assertEqual(SetMute["directive"]["header"]["name"], "SetMute")
        self.assertNotEqual(SetMute["directive"]["header"]["messageId"], "1")
        #self.assertEqual(SetMute["directive"]["header"]["dialogRequestId"],"234qazwsx")
        if SetMute["directive"]["payload"]["mute"] in [False ,True]:
            mute = True
        else:
            mute = False
        self.assertTrue(mute)

        #print r3
        Speak = json.loads(r3)
        self.assertEqual(Speak["directive"]["header"]["namespace"], "SpeechSynthesizer")
        self.assertEqual(Speak["directive"]["header"]["name"], "Speak")
        self.assertNotEqual(Speak["directive"]["header"]["messageId"], "1")
        #self.assertEqual(Speak["directive"]["header"]["dialogRequestId"],"234qazwsx")
        self.assertEqual(Speak["directive"]["payload"]["format"],"AUDIO_MPEG")
        u = re.compile(r"(.*):(\w+)").findall(Speak["directive"]["payload"]["url"])
        url= u[0][0] + ":"
        self.assertEqual(url,"cid:")

        #print r4
        ExpectSpeech = json.loads(r4)
        self.assertEqual(ExpectSpeech["directive"]["header"]["namespace"], "SpeechRecognizer")
        self.assertEqual(ExpectSpeech["directive"]["header"]["name"], "ExpectSpeech")
        self.assertNotEqual(ExpectSpeech["directive"]["header"]["messageId"], "1")
        #self.assertEqual(Speak["directive"]["header"]["dialogRequestId"],"234qazwsx")
        #print "res %s" %res
        streamid2 = self.conn.request(post, eventspath, body=exitbody, headers=self.Pheader)
        response2 = self.conn.get_response(stream_id=streamid2)
        status2 = response2.status
        res2 =  response2.read()
        self.assertEqual(status2,200)
        r = re.compile(r"(--\w+-\w+-\w+-\w+-\w+)\s*Content-Type: application/json; charset=UTF-8;\s*(.*)\s*(--\w*-\w*-\w*-\w*-\w*--)").findall(res2)[0]
        print r[1]
        ReadOff = json.loads(r[1])
        self.assertEqual(ReadOff["directive"]["header"]["namespace"], "SpeechSynthesizer")
        self.assertEqual(ReadOff["directive"]["header"]["name"], "ReadOff")
        self.assertNotEqual(ReadOff["directive"]["header"]["messageId"], "a397a255-53be-41fc-996b-521413e9e22d")
        #self.assertEqual(ReadOff["directive"]["header"]["dialogRequestId"],"518e1f56-0857-49a7-a5d0-528277751b99")
        if  ReadOff["directive"]["payload"]["format"]  in ["plainText","objectText"]:
            fm = True
        else:
            fm = False
        #self.assertTrue(fm)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        self.conn.close()

if __name__ == "__main__":
    unittest.main()





