#! /usr/python/bin
# -*- coding=UTF-8 -*-

'''
Created on 2018年3月1日
@author: yinyd1
'''

import time
import unittest
from hyper import HTTP20Connection
from config import *
from Public import *
import requests
import json

def test_pushskill():
    pushd = json.dumps(pushdata)
    body = bodydata("pushskill", "trueskillkey", "Event",pushd)
    testdata = eval(body.encode("utf-8"))
    conn = requests.post(pushurl,data=None,json=testdata,headers=pushheader)
    content = json.loads(conn.content)
    status = conn.status_code
    code = content["code"]
    print status
    print content
    assert status==200
    assert code == 0

if __name__=="__main__":
    test_pushskill()

