# -*- coding:utf-8 -*-
'''
Created on 2017年4月20日
@author: yinyd
'''
import requests
import json
import time
import pytest
if __name__ == '__main__':
    now = time.strftime("%Y-%m-%M_%H_%M_%S", time.localtime(time.time()))
    pytest.main("--html=./Report/"+now+"report.html")