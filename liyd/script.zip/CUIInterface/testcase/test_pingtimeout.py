#! /usr/python/bin
# -*- coding=UTF-8 -*-

import time
import unittest
from hyper import HTTP20Connection
from config import *
from Public import *

class pingtimeout(unittest.TestCase):

    def setUp(self):
        self.verificationErrors = []
        self.Aheader = Header
        self.conn = HTTP20Connection(host=domain, port=port, secure=True)
        self.accept_next_alert = True

    def directives(self,conn):
        streamid = conn.request(get, directivespath, headers=Header)
        response = conn.get_response(stream_id=streamid)
        h = response.headers
        # print h
        status = response.status
        assert status == 200

        return True

    def test_pingtimeout(self):
        #******************************************修改用户信息******************************************************
        u"""正确歌手正确歌手"""
        status = self.directives(self.conn)
        print "连接成功"
        print status
        assert status == True

        time.sleep(60)

        streamid = self.conn.request(get, pingpath, headers=pingHeader)
        print streamid
        #time.sleep(10000)
        try:
            response = self.conn.get_response(streamid)
            h = response.headers
            print h
            status = response.status
            print status
            assert status == 204
            print "success"
        except:

            reason = "Request timeout"
        assert reason == "Request timeout"

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        self.conn.close()

if __name__ == "__main__":
    unittest.main()





