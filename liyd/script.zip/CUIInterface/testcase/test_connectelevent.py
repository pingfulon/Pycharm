#! /usr/python/bin
# -*- coding=UTF-8 -*-

import time
import unittest
from hyper import HTTP20Connection
from config import *
from Public import *

class connectelevent(unittest.TestCase):

    def setUp(self):
        self.verificationErrors = []
        self.Aheader = Header
        self.conn = HTTP20Connection(host=domain, port=port, secure=True)
        self.accept_next_alert = True

    def test_test(self):
        #******************************************修改用户信息******************************************************
        u"""正确歌手正确歌手"""
        num = self.conn.request(get, directivespath, headers=self.Aheader)
        print num
        response = self.conn.get_response(stream_id=num)
        # h = response.headers
        status = response.status
        assert status==200
        time.sleep(10)
        num1 = self.conn.request(get, directivespath, headers=self.Aheader)
        print num1
        try:
            response = self.conn.get_response(stream_id=num1)
            # h = response.headers
            status = response.status
            assert status == 200
            print status
        except:
            close = "Stream closed"

        assert close == "Stream closed"

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        self.conn.close()

if __name__ == "__main__":
    unittest.main()

