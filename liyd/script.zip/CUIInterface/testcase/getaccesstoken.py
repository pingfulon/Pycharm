#! /usr/python/bin
# -*- coding=UTF-8 -*-
'''
Created on 2018年3月1日
@author: yinyd1
'''

import json
import httplib
import requests
import xml.etree.cElementTree as ET

#domain = "testcuiauth.lenovo.com.cn:8443"
domain = "pvtcuiauth.lenovo.com.cn:443"
port = "8003"
reqauthpath = "/auth"
#authurl = "https://pvtcuiauth.lenovo.com.cn:443/auth/v1/token"
authurl = "https://testcuiauth.lenovo.com.cn:8443/auth/v1/token "

header = {'Content-Type': 'application/json'}
getstheader = {'Content-Type': 'application/x-www-form-urlencoded'}
tgturl = 'https://uss.lenovomm.com/authen/1.2/tgt/user/get?msisdn=18910862390'
tgtdata = 'password=12346789&source=android:com.lenovomm.rocket.clientlogin-1.0&deviceidtype=imei&deviceid=863664000005859&' \
           'devicecategory=phone&devicevendor=lenovo&devicefamily=lephone&devicemodel=3GW100&extrainfo=sds&imsi=460022101506978' \
           '&lang=zh_CN&androidid=012abcDEF&osversion=android.os.Build.VERSION.RELEASE&productiondate=2011-09-15 00:00:00&' \
           'unpackdate=2011-09-15 00:00:00&bindpid=12345601&pidpwd=517A7774756F7553335A&areacode=%2b86'

def getlenovoidtoken():
    tgtres = requests.post(tgturl, data=tgtdata, json=None, headers= getstheader)
    #print tgtres.status_code
    tgtcontent = tgtres.content
    #print tgtcontent
    root = ET.fromstring(tgtcontent)
    books = root.findall('TicketInfo')
    for country in books:
        tgt = country.find('Value').text

    #print tgt
    sturl = 'https://uss.lenovomm.com/authen/1.2/st/get?realm=api.iot.lenovomm.com&lpsutgt=' + tgt + '&source=android:com.lenovomm.rocket.clientlogin-1.0'
    stres = requests.get(sturl, params=None, headers=getstheader)
    #print stres.status_code
    stcontent = stres.content
    troot = ET.fromstring(stcontent)
    tbook = troot.findall('TicketInfo')
    for xml in tbook:
        token = xml.find('Value').text
    print token

    return token


conn = httplib.HTTPSConnection(domain)
token = getlenovoidtoken()
#t = bodydata("Auth", "correctreq", token)
testdata = {
        "product_id" : "tv",
        "client_key": "abcd567890123456",
        "device_info":{
        "vendor": "lenovo",
        "mac" : "1234567890123456",
        "deviceid": "12345678"
        },
        "lenovo_id_info":{
        "ticket": token,
        "realm" : "api.iot.lenovomm.com"
        }}
#print testdata
conn.request("POST",authurl,body=json.dumps(testdata),headers=header)
response = conn.getresponse()
#print response.status
res = json.loads(response.read())
#print res
code=res["code"]
accesstoken = res["data"]["access_token"]
refreshtoken = res["data"]["refresh_token"]
print accesstoken