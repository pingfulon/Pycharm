#! /usr/python/bin
# -*- coding=UTF-8 -*-

import unittest
from Public import *
import connect
from config import *
import json

class SpeechRecognizerRecognizeOBVoice(unittest.TestCase):

    def setUp(self):
        self.verificationErrors = []
        self.Pheader = Pheader
        self.conn = connect.conn
        self.accept_next_alert = True

    def test_RecognizeOBVoice(self):
        #******************************************修改用户信息******************************************************
        u"""验证半关闭"""


        body = bodydata("SpeechRecognizer","RecognizeOBVoice","Event")
        testbody = httpdatabinary(str(body),"./audiofile/xiaole_cn.wav")
        #testbody = httpdatatext(body)

        streamid1 = self.conn.request(post,eventspath,body=str(testbody),headers=self.Pheader)
        print streamid1
        response = self.conn.get_response(stream_id=streamid1)
        h = response.headers
        print h
        status = response.status
        print status
        assert status == 200
        res = response.read()
        print res
        r1, r2, r3, r4 = getresponsebin(res)
        print r4
        StopCapture = json.loads(r1)
        self.assertEqual(StopCapture["directive"]["header"]["name"], "StopCapture")
        self.assertEqual(StopCapture["directive"]["header"]["namespace"], "SpeechRecognizer")
        self.assertNotEqual(StopCapture["directive"]["header"]["messageId"], "1")
        #self.assertEqual(StopCapture["directive"]["header"]["dialogRequestId"],"qwerfd1213232")
        # print r2
        SetMute = json.loads(r2)
        self.assertEqual(SetMute["directive"]["header"]["namespace"], "Speaker")
        self.assertEqual(SetMute["directive"]["header"]["name"], "SetMute")
        self.assertNotEqual(SetMute["directive"]["header"]["messageId"], "1")
        self.assertEqual(SetMute["directive"]["header"]["dialogRequestId"],"qwerfd1213232")
        if SetMute["directive"]["payload"]["mute"] in [False ,True]:
            mute = True
        else:
            mute = False
        self.assertTrue(mute)

        print r3
        Speak = json.loads(r3)
        self.assertEqual(Speak["directive"]["header"]["namespace"], "SpeechSynthesizer")
        self.assertEqual(Speak["directive"]["header"]["name"], "Speak")
        self.assertNotEqual(Speak["directive"]["header"]["messageId"], "1")
        #self.assertEqual(Speak["directive"]["header"]["dialogRequestId"],"qwerfd1213232")
        self.assertEqual(Speak["directive"]["payload"]["format"], "AUDIO_MPEG")
        u = re.compile(r"(.*):(\w+)").findall(Speak["directive"]["payload"]["url"])
        url = u[0][0] + ":"
        self.assertEqual(url, "cid:")

        MetaData = json.loads(r4)
        #print MetaData
        self.assertEqual(MetaData["directive"]["header"]["namespace"], "TemplateRuntime")
        self.assertEqual(MetaData["directive"]["header"]["name"], "MetaData")
        self.assertNotEqual(MetaData["directive"]["header"]["messageId"], "1")
        #self.assertEqual(MetaData["directive"]["header"]["dialogRequestId"],"qwerfd1213232")
        self.assertEqual(MetaData["directive"]["payload"]["format"], "json")
        print MetaData["directive"]["payload"]["modelName"]
        if MetaData["directive"]["payload"]["modelName"] in modelname:
            MN= True
        else:
            MN = False
        self.assertTrue(MN)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        self.conn.close()

if __name__ == "__main__":
    unittest.main()





