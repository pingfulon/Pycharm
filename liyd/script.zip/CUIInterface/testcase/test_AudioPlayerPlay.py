#! /usr/python/bin
# -*- coding=UTF-8 -*-

import unittest
from Public import *
import connect
from config import *
import json
import time
import re

class AudioPlayerPlay(unittest.TestCase):

    def setUp(self):
        self.verificationErrors = []
        self.Pheader = Pheader
        self.conn = connect.conn
        self.accept_next_alert = True

    def test_Play(self):
        #******************************************修改用户信息******************************************************
        u"""验证ProcTextRequest"""

        body = bodydata("AudioPlayer","Play","openDirective")
        # databody=str(body).encode("utf-8")
        testbody = httpdatatext(body)
        #print testbody
        streamid1 = self.conn.request(post, eventspath, body=testbody, headers=self.Pheader)

        print streamid1
        response = self.conn.get_response(stream_id=streamid1)
        h = response.headers
        # print h
        status = response.status
        print status
        assert status == 200
        content = response.read()
        #print content



        body = bodydata("AudioPlayer","Play","Directive")
        #databody=str(body).encode("utf-8")
        testbody = httpdatatext(body)
        print testbody
        streamid1 = self.conn.request(post,eventspath,body=testbody,headers=self.Pheader)

        print streamid1
        response = self.conn.get_response(stream_id=streamid1)
        h = response.headers
        #print h
        status = response.status
        print status
        #assert status == 200
        content =response.read()
        #print "condsd %s" % content
        #r1,r2,r3,r4=getresponseset(content)
        #print r4
        res = getresponseset(content)
        #print res
        ProcNLUResult = json.loads(res)
        self.assertEqual(ProcNLUResult["directive"]["header"]["namespace"], "DataTransmission")
        self.assertEqual(ProcNLUResult["directive"]["header"]["name"], "ProcNLUResult")
        self.assertNotEqual(ProcNLUResult["directive"]["header"]["messageId"], "a397a255-53be-41fc-996b-521413e9e22d")
        self.assertEqual(ProcNLUResult["directive"]["header"]["dialogRequestId"],"518e1f56-0857-49a7-a5d0-528277751b99")
        self.assertEqual(ProcNLUResult["directive"]["payload"]["slots"][1][u"歌手名"],u"刘德华")
        self.assertEqual(ProcNLUResult["directive"]["payload"]["slots"][1][u"歌曲名"], u"忘情水")
        self.assertEqual(ProcNLUResult["directive"]["payload"]["slots"][1]["intent"], "SKI.NLUResultIntent")

        ebody = bodydata("SpeechRecognizer", "ProcTextRequest", "EventExit")
        exitbody = httpdatatext(str(ebody))
        streamid2 = self.conn.request(post, eventspath, body=exitbody, headers=self.Pheader)
        response2 = self.conn.get_response(stream_id=streamid2)
        status2 = response2.status
        res2 = response2.read()
        self.assertEqual(status2, 200)


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        self.conn.close()

if __name__ == "__main__":
    unittest.main()





