#! /usr/python/bin
# -*- coding=UTF-8 -*-

import unittest
from Public import *
import connect
from config import *
import json
import re

class SpeechSynthesizerSpeechStarted(unittest.TestCase):

    def setUp(self):
        self.verificationErrors = []
        self.Pheader = Pheader
        self.conn = connect.conn
        self.accept_next_alert = True

    def test_SpeechStarted(self):
        #******************************************修改用户信息******************************************************
        u"""验证ProcTextRequest"""
        body = bodydata("SpeechSynthesizer","SpeechStarted","Event")
        testbody = httpdatatext(str(body))
        # print testbody
        streamid1 = self.conn.request(post,eventspath,body=testbody,headers=self.Pheader)
        print streamid1
        response = self.conn.get_response(stream_id=streamid1)
        h = response.headers
        #print h
        status = response.status
        print status
        assert status == 204


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        self.conn.close()

if __name__ == "__main__":
    unittest.main()





