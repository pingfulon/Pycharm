#! /usr/python/bin
# -*- coding=UTF-8 -*-

from Public import *
from hyper import HTTP20Connection,tls
import threading
import time
from config import *
from time import ctime


def directives(conn):
    streamid = conn.request(get, directivespath, headers=Header)
    print streamid
    response = conn.get_response(stream_id=streamid)
    h = response.headers
    #print h
    status = response.status
    print status
    assert status == 200

    return streamid

def openthread(conn):
    thread = MyThread(1, "thread-1", 100)
    #thread.setDaemon(True)
    thread.start()


class MyThread(threading.Thread):
    def __init__(self, threadID, name, counter):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.counter = counter

    def run(self):
        ping(self.name, 1, self.counter)


def ping(name, delay, counter):
    while counter:
        print "Live package sent: %d" % counter
        streamid = conn.request(get, pingpath, headers=pingHeader)
        response = conn.get_response(streamid)
        h = response.headers
        # print h
        status = response.status
        print status
        assert status == 204
        print "success"
        counter -= 1
        time.sleep(delay)




conn = HTTP20Connection(host=domain, port=port, secure=True)
print domain,port
streamid = directives(conn)
#print ctime()
#streamid2 = conn.request(get, pingpath, headers=Header)
#print streamid2

#print streamid
assert streamid == 1

#conn.close()
#openthread(conn)
#time.sleep(10)



