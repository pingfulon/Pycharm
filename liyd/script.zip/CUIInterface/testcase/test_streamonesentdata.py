#! /usr/python/bin
# -*- coding=UTF-8 -*-

import time
import unittest
import json
from Public import *
import connect
from time import ctime

class streamonesentdata(unittest.TestCase):

    def setUp(self):
        self.verificationErrors = []
        self.Aheader = Header
        self.conn = connect.conn
        self.stream_id = connect.streamid
        self.accept_next_alert = True

    def test_streamonesentdata(self):
        #******************************************修改用户信息******************************************************
        u"""验证半关闭"""

        try:
            self.conn.send(data=json.dumps(testdata), final=True, stream_id=self.stream_id)
            print ctime()
            response = self.conn.get_response(stream_id=self.stream_id)
            h = response.headers
            print h
            status = response.status
            assert status == 204
            print "success"
        except:
            reason = "half close"
        assert reason == "half close"
        print ctime()

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        self.conn.close()

if __name__ == "__main__":
    unittest.main()





