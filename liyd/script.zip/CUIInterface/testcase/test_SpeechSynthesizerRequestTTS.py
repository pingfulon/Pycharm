#! /usr/python/bin
# -*- coding=UTF-8 -*-

import unittest
from Public import *
import connect
from config import *
import json
import re

class SpeechSynthesizerRequestTTS(unittest.TestCase):

    def setUp(self):
        self.verificationErrors = []
        self.Pheader = Pheader
        self.conn = connect.conn
        self.accept_next_alert = True

    def test_RequestTTS(self):
        #******************************************修改用户信息******************************************************
        u"""验证ProcTextRequest"""
        body = bodydata("SpeechSynthesizer","RequestTTS","Event")
        testbody = httpdatatext(str(body))
        #print testbody
        streamid1 = self.conn.request(post,eventspath,body=testbody,headers=self.Pheader)
        print streamid1
        response = self.conn.get_response(stream_id=streamid1)
        h = response.headers
        #print h
        status = response.status
        res = response.read()
        print status
        r1,r2 = getresponseSPK(res)
        print r1
        print r2
        SetMute = json.loads(r1)
        self.assertEqual(SetMute["directive"]["header"]["namespace"], "Speaker")
        self.assertEqual(SetMute["directive"]["header"]["name"], "SetMute")
        self.assertNotEqual(SetMute["directive"]["header"]["messageId"], "123EEWR")
        self.assertEqual(SetMute["directive"]["header"]["dialogRequestId"],"RYEWIRYW36493284")
        if SetMute["directive"]["payload"]["mute"] in [False ,True]:
            mute = True
        else:
            mute = False
        self.assertTrue(mute)

        Speak = json.loads(r2)
        self.assertEqual(Speak["directive"]["header"]["namespace"], "SpeechSynthesizer")
        self.assertEqual(Speak["directive"]["header"]["name"], "Speak")
        self.assertNotEqual(Speak["directive"]["header"]["messageId"], "123EEWR")
        # self.assertEqual(Speak["directive"]["header"]["dialogRequestId"],"RYEWIRYW36493284")
        self.assertEqual(Speak["directive"]["payload"]["format"], "AUDIO_MPEG")
        u = re.compile(r"(.*):(\w+)").findall(Speak["directive"]["payload"]["url"])
        url = u[0][0] + ":"
        self.assertEqual(url, "cid:")
        #assert status == 204


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        self.conn.close()

if __name__ == "__main__":
    unittest.main()





