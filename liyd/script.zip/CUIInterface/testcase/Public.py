#! /usr/python/bin
# -*- coding=UTF-8 -*-

import xlrd
from config import *
import re

#******************************************方法****************************************

def bodydata(NameSpace,names,types,*arg):
    data = xlrd.open_workbook("casedata.xlsx")
    table = data.sheet_by_name(NameSpace)
    nrows = table.nrows
    ncols = table.ncols

    for i in range(nrows - 1):

        name = table.cell(i + 1, 0).value
        #print "DDDD %s" % name
        if name == names:

            data = table.cell(i + 1, 1).value
            #print data
            if data == types:
                bodydata1 = table.cell(i + 1, 2).value
                break

        else:
            pass
    databody = str(bodydata1).encode("utf-8")

    #print bodydata1
    return databody

def bincontext(context):

    reqcontext = ""
    for i in context:
        bindata = format(ord(i), 'b')
        reqcontext += bindata
        #print bindata
        #print reqcontext
    return reqcontext

def httpdatatext(bodydata):
    data = []
    data.append("--%s" % boundary)
    data.append('Content-Disposition: form-data; name="metadata"')
    data.append("Content-Type: application/json; charset=UTF-8")
    data.append("")
    data.append(bodydata)
    data.append("")
    data.append("--%s--" % boundary)
    data.append("")
    textbody = '\r\n'.join(data)
    #print textbody
    return textbody

def httpdatabinary(bodydata,filename):
    data = []
    fp = open(filename, "rb")
    data.append("--%s" % boundary)
    data.append('Content-Disposition: form-data; name="metadata"')
    data.append("Content-Type: application/json; charset=UTF-8")
    data.append("")
    data.append(bodydata)
    data.append("--%s" % boundary)
    data.append("Content-Disposition: form-data; name='audio'")
    data.append("Content-Type: application/octet-stream")
    data.append("")
    data.append(fp.read())
    fp.close()
    data.append("--%s--" %boundary)
    data.append("")
    binarybody = '\r\n'.join(data)
    #print binarybody
    return binarybody

def getresponsebin(res):
    v = re.compile(
        r"(--\w+-\w+-\w+-\w+-\w+)\s*Content-Type: application/json; charset=UTF-8;(.*)\s*(--\w+-\w+-\w+-\w+-\w+)\s*Content-Type: application/octet-stream;(.*)(--\w+-\w+-\w+-\w+-\w+)\s*Content-Type: application/json; charset=UTF-8;(.*)\s*(--\w+-\w+-\w+-\w+-\w+--)",
        re.M | re.I | re.S).findall(res)[0]
    # print v[1]
    c = re.compile(
        r"(.*)\s*(--\w+-\w+-\w+-\w+-\w+)\s*Content-Type: application/json; charset=UTF-8;(.*)\s*(--\w+-\w+-\w+-\w+-\w+)\s*Content-Type: application/json; charset=UTF-8;(.*)",
        re.M | re.I | re.S).findall(v[1])[0]
    #print c[0]
    #print c[2]
    #print c[4]
    #print v[5]
    return c[0],c[2],c[4] ,v[5]

def getresponseSPK(res):
    v = re.compile(
        r"(--\w+-\w+-\w+-\w+-\w+)\s*Content-Type: application/json; charset=UTF-8;(.*)\s*(--\w+-\w+-\w+-\w+-\w+)\s*Content-Type: application/octet-stream;(.*)(--\w+-\w+-\w+-\w+-\w+)\s*",
        re.M | re.I | re.S).findall(res)[0]
    #print v[1]
    c = re.compile(
        r"(.*)\s*(--\w+-\w+-\w+-\w+-\w+)\s*Content-Type: application/json; charset=UTF-8;(.*)\s*",
        re.M | re.I | re.S).findall(v[1])[0]

    return c[0],c[2]

def getresponsetext(res):
    res1 = re.compile(
        r"(--\w+-\w+-\w+-\w+-\w+)\s*Content-Type: application/json; charset=UTF-8;(.*)\s*(--\w+-\w+-\w+-\w+-\w+)\s*Content-Type: application/octet-stream;(.*)(--\w+-\w+-\w+-\w+-\w+)\s*Content-Type: application/json; charset=UTF-8;(.*)\s*(--\w+-\w+-\w+-\w+-\w+)",
        re.M | re.I | re.S).findall(res)[0]
    #print res1
    # print res1[5]
    res2 = re.compile(
        r"(.*)\s*(--\w+-\w+-\w+-\w+-\w+)\s*Content-Type: application/json; charset=UTF-8;(.*)\s*",
        re.M | re.I | re.S).findall(res1[1])[0]
    #print res2
    #res = re.compile(r"(--\w+-\w+-\w+-\w+-\w+)\s*Content-Type: application/json; charset=UTF-8;\s*(.*)").findall(res1[1])[0][1]
    return res1[3] ,res2[0],res2[2],res1[5]

def getresponseset(res):
    res1 = re.compile(
        r"(--\w+-\w+-\w+-\w+-\w+)\s*Content-Type: application/json; charset=UTF-8;(.*)\s*(--\w+-\w+-\w+-\w+-\w+--)",
        re.M | re.I | re.S).findall(res)[0]
    return res1[1]

#***************************************报文内容***************************************
Header = {
            ":method": get,
            ":scheme": scheme,
            ":path": directivespath,
            "authorization": authorization,
            "content-type": contenttypejson
        }
pingHeader = {
            ":method": get,
            ":scheme": scheme,
            ":path": pingpath,
            "authorization": authorization,
            "content-type": contenttypejson
}
Pheader = {
            ":method": post,
            ":scheme": scheme,
            ":path": eventspath,
            "authorization": authorization,
            "content-type": contenttypebinary
        }
ErrorHeader = {
            ":method": get,
            ":scheme": scheme,
            ":path": eventspath,
            "authorization": "Bearer fdd2b2d73eb21b77de9bf40c74d3fe356918afd8aa82f59aad4f02789d3207d",
            "content-type": contenttypejson
        }

testdata = {"AB":"test"}

pushheader = {"Content-Type": "application/json"}
