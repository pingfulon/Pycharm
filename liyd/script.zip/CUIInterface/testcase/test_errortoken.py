#! /usr/python/bin
# -*- coding=UTF-8 -*-

import time
import unittest
from hyper import HTTP20Connection
from config import *
from Public import *

class test(unittest.TestCase):

    def setUp(self):
        self.verificationErrors = []
        self.Aheader = ErrorHeader
        self.conn = HTTP20Connection(host=domain, port=port, secure=True)
        self.accept_next_alert = True

    def test_test(self):
        #******************************************修改用户信息******************************************************
        u"""正确歌手正确歌手"""

        #time.sleep(11)
        num = self.conn.request(get, directivespath, headers=self.Aheader)
        print num
        response = self.conn.get_response(stream_id=num)
        #h = response.headers
        status = response.status
        print status
        assert status == 403

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        self.conn.close()

if __name__ == "__main__":
    unittest.main()

