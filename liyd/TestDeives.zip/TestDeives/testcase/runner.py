#! /usr/python/bin
# -*- coding=UTF-8 -*-
'''
Created on 2018年3月1日
@author: yinyd1
'''

import requests
import json
import time
import pytest
if __name__ == '__main__':

    pytest.main("--html=./Report/report.html")