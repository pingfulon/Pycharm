#! /usr/python/bin
# -*- coding=UTF-8 -*-

#from getaccesstoken import *

domain = "devcui.lenovo.com.cn"
#domain = "10.120.114.184"
#domain = "pvtcui.lenovo.com.cn"
port = "9443"
eventspath = "/v20170930/events"
directivespath = "/v20170930/directives"
pingpath = "/ping"
post = "POST"
get = "GET"
boundary = "this-is-a-boundary"
scheme = "https"
pcauthorization = "Bearer 5a5de354c21be35de1bb58f1"
speakerauthorization = "Bearer 5a5de353c21be35de1bb58d2"
#print authorization
contenttypejson = "multipart/form-data; boundary=this-is-a-boundary"
contenttypebinary = "multipart/form-data; boundary=this-is-a-boundary"
modelname = ["TEXT_CONTENT","FETCHING_DIRECTLY","WEATHER","MUSIC_KUWO","EDUCATION_CEX","VCN_RESULT"]
playbehavior = ["REPLACE_ALL","ENQUEUE","REPLACE_ENQUEUED"]
pushdata = {"mac":"ABCDABCDABCE","vendor":"lenovo EDUi"}
pushurl =  "http://10.120.22.108:15222/push/skill"
