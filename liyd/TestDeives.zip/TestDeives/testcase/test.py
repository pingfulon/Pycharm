#! /usr/python/bin
# -*- coding=UTF-8 -*-

from Public import *
import connect
import json
import time

def directives(conn):
    headerdata = Header(pcauthorization)
    streamid = conn.request(get, directivespath, headers=headerdata)
    #print streamid
    response = conn.get_response(stream_id=streamid)
    status = response.status
    print status
    assert status == 200

    return streamid

if __name__ == "__main__":
    directives(connect.conn)
    pheaderdata = Pheader(pcauthorization)
    ask = "查看本地服务"
    t= bodydata("SpeechRecognizer","ProcTextRequest","EventText")
    body = eval(t.encode("utf-8"))
    testbody = httpdatatext(json.dumps(body).encode("utf-8"))
    #print testbody
    estarttime = int(round(time.time() * 1000))
    streamid1 = connect.conn.request(post,eventspath,body=testbody,headers=pheaderdata)
    #print streamid1
    response = connect.conn.get_response(stream_id=streamid1)
    h = response.headers
    # print h
    status = response.status
    print status
    #assert status == 200
    content = response.read()
    print content