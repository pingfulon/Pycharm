#! /usr/python/bin
# -*- coding=UTF-8 -*-
'''
Created on 2018年3月1日
@author: yinyd1
'''

from Public import *
import connect
import json
import time


def directives(conn):
    headerdata = Header(pcauthorization)
    streamid = conn.request(get, directivespath, headers=headerdata)
    #print streamid
    response = conn.get_response(stream_id=streamid)
    status = response.status
    #print status
    assert status == 200

    return streamid

def test_devicecalendar():
    pheaderdata = Pheader(pcauthorization)
    data = xlrd.open_workbook('devicedata.xlsx')
    table = data.sheet_by_name("calendar")
    nrows = table.nrows
    ncols = table.ncols
    wbnew = copy(data)
    ws = wbnew.get_sheet(1)

    starttime = int(round(time.time() * 1000))
    for i in range(nrows-1):
        file = open("calendarlog.txt", "a+")
        dmname= str(table.cell(1 + i, 2).value).encode("utf-8")
        print dmname
        file.write(dmname)
        ask = str(table.cell(1 + i, 3).value).encode("utf-8")
        print ask
        file.write("\n")
        file.write(ask)

        t= bodydata("SpeechRecognizer","ProcTextRequest","EventText")
        body = eval(t.encode("utf-8"))
        testbody = httpdatatext(json.dumps(body).encode("utf-8"))
        #print testbody
        estarttime = int(round(time.time() * 1000))
        streamid1 = connect.conn.request(post,eventspath,body=testbody,headers=pheaderdata)
        #print streamid1
        response = connect.conn.get_response(stream_id=streamid1)
        h = response.headers
        # print h
        status = response.status
        print status
        #assert status == 200
        content = response.read()
        print content
        # r1=getresponseone(content)
        # print r1
        # res1=json.loads(r1)
        # assert res1["directive"]["payload"]["content"]["domain"] == u"会议查询取消"
        # assert res1["directive"]["payload"]["content"]["input"].encode("utf-8") == ask
        # assert res1["directive"]["payload"]["content"]["intent"][1][u"操作"].encode("utf-8")== dmname
        eendtime = int(round(time.time() * 1000))
        etime_difference= eendtime - estarttime

        ws.write(i + 1, 6, etime_difference)
        wbnew.save('calendarresultcase.xlsx')

        #file.write(str(etime_difference))
        #print u"请求和响应的时间差值 : %d ms" % etime_difference
        #print content
        file.write(content)
        if dmname in content:
            ws.write(i + 1, 5, "pass")
            wbnew.save('calendarresultcase.xlsx')
        else:
            ws.write(i + 1, 5, "fail")
            wbnew.save('calendarresultcase.xlsx')

        file.close()
    endtime = int(round(time.time() * 1000))
    time_difference = endtime - starttime
    #file.write(str(time_difference))
    print u"请求和响应的时间差值 : %d ms" % time_difference

if __name__ == "__main__":
    directives(connect.conn)
    test_devicecalendar()