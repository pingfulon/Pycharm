#! /usr/python/bin
# -*- coding=UTF-8 -*-
'''
Created on 2018年3月1日
@author: yinyd1
'''

from Public import *
import connect
import json
import time

def test_deviceweather():
    pheaderdata = Pheader(pcauthorization)
    data = xlrd.open_workbook('devicedata.xlsx')
    table = data.sheet_by_name("Weather")
    nrows = table.nrows
    ncols = table.ncols
    wbnew = copy(data)
    ws = wbnew.get_sheet(0)

    starttime = int(round(time.time() * 1000))
    for i in range(nrows-1):
        file = open("weatherlog.txt", "a+")
        dmname= str(table.cell(1 + i, 2).value).encode("utf-8")
        print dmname
        file.write(dmname)
        ask = str(table.cell(1 + i, 3).value).encode("utf-8")
        print ask
        file.write("\n")
        file.write(ask)

        t= bodydata("SpeechRecognizer","ProcTextRequest","EventText")
        body = eval(t.encode("utf-8"))
        testbody = httpdatatext(json.dumps(body).encode("utf-8"))
        #print testbody
        estarttime = int(round(time.time() * 1000))
        streamid1 = connect.conn.request(post,eventspath,body=testbody,headers=pheaderdata)
        #print streamid1
        response = connect.conn.get_response(stream_id=streamid1)
        h = response.headers
        # print h
        status = response.status
        print status
        #assert status == 200
        content = response.read()
        #print content
        eendtime = int(round(time.time() * 1000))
        etime_difference = eendtime - estarttime

        ws.write(i + 1, 6, etime_difference)
        wbnew.save('weatherresultcase.xlsx')

        file.write(content)
        try:
            r1=getresponseweather(content)
            #print r1
            #print r2
            res1=json.loads(r1)
            #print res1
            assert res1["directive"]["payload"]["content"]["city"].encode("utf-8") == dmname
            assert res1["directive"]["payload"]["modelName"] == "WEATHER"
            assert res1["directive"]["payload"]["format"] == "JSON"
            ws.write(i + 1, 5, "pass")
            wbnew.save('weatherresultcase.xlsx')
        except:
            ws.write(i + 1, 5, "fail")
            wbnew.save('weatherresultcase.xlsx')

        # eendtime = int(round(time.time() * 1000))
        # etime_difference= eendtime - estarttime
        #
        # ws.write(i + 1, 6, etime_difference)
        # wbnew.save('weatherresultcase.xlsx')

        #file.write(str(etime_difference))
        #print u"请求和响应的时间差值 : %d ms" % etime_difference
        #print content
        # file.write(content)
        # if dmname in content:
        #     ws.write(i + 1, 5, "pass")
        #     wbnew.save('weatherresultcase.xlsx')
        # else:
        #     ws.write(i + 1, 5, "fail")
        #     wbnew.save('weatherresultcase.xlsx')

        file.close()
    endtime = int(round(time.time() * 1000))
    time_difference = endtime - starttime
    #file.write(str(time_difference))
    print u"请求和响应的时间差值 : %d ms" % time_difference

if __name__ == "__main__":
    test_deviceweather()