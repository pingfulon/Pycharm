#! /usr/python/bin
# -*- coding=UTF-8 -*-
'''
Created on 2018年3月1日
@author: yinyd1
'''

from Public import *
import connect
import json
import time

def test_devicemusic():
    pheaderdata = Pheader(pcauthorization)
    data = xlrd.open_workbook('devicedata.xlsx')
    table = data.sheet_by_name("music")
    nrows = table.nrows
    ncols = table.ncols
    wbnew = copy(data)
    ws = wbnew.get_sheet(4)

    starttime = int(round(time.time() * 1000))
    for i in range(nrows-1):
        file = open("musiclog.txt", "a+")
        dmname= str(table.cell(1 + i, 2).value).encode("utf-8")
        print dmname
        file.write(dmname)
        ask = str(table.cell(1 + i, 3).value).encode("utf-8")
        print ask
        file.write("\n")
        file.write(ask)

        t= bodydata("SpeechRecognizer","ProcTextRequest","EventText")
        body = eval(t.encode("utf-8"))
        testbody = httpdatatext(json.dumps(body).encode("utf-8"))
        estarttime = int(round(time.time() * 1000))
        streamid1 = connect.conn.request(post,eventspath,body=testbody,headers=pheaderdata)
        response = connect.conn.get_response(stream_id=streamid1)
        h = response.headers
        status = response.status
        print status
        content = response.read()
        #print
        eendtime = int(round(time.time() * 1000))
        etime_difference= eendtime - estarttime

        ws.write(i + 1, 6, etime_difference)
        wbnew.save('musicresultcase.xlsx')

        file.write(content)
        try:
            r1=getresponseone(content)
            res1=json.loads(r1)
            #print res1
            assert res1["directive"]["payload"]["domain"].encode("utf-8") == dmname
            assert res1["directive"]["payload"]["input"].encode("utf-8") == ask
            assert res1["directive"]["payload"]["slots"][1]["intent"] == "SKI.NLUResultIntent"
            ws.write(i + 1, 5, "pass")
            wbnew.save('musicresultcase.xlsx')
        except:
            ws.write(i + 1, 5, "fail")
            wbnew.save('musicresultcase.xlsx')


        file.close()
    endtime = int(round(time.time() * 1000))
    time_difference = endtime - starttime
    #file.write(str(time_difference))
    print u"请求和响应的时间差值 : %d ms" % time_difference

if __name__ == "__main__":
    test_devicemusic()