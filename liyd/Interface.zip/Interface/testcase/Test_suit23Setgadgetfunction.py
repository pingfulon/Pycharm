#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json,time
import Public
import websockethub,websocketclient
import unittest
from creategadget import gadget_id

class setgadgetfunction(unittest.TestCase):

    def setUp(self):
        self.wsh = websockethub.ws
        self.wsc = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsh, message):
        # print "hub %s" % message
        if "set_gadget_function" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            self.assertEqual(code, u"0")
            result = "true"

        else:
            result = "false"

        return result

    def test_Sgadgetfunction(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""
        wsh = self.wsh
        testdata = Public.setgadgetfunction_databy(str(gadget_id))
        print testdata
        wsh.send(json.dumps(testdata))
        for i in range(15):
            message = wsh.recv()
            #print u"sssssssmessage %s" % message

            result = self.on_message(wsh, message)
            #print u"result %s " % result
            #time.sleep(2)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()

if __name__ == "__main__":
    unittest.main()