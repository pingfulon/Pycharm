#!/usr/bin/python
# -*- coding:UTF-8 -*-

import json
import ssl
import threading
import time

import websocket

from Data import *


def on_message(ws, message):
    print "hub %s" % message
    if "qos_type" in message:
        Websocketres = json.loads(message)
        qos_type = Websocketres["qos_type"]
        msg_type = Websocketres["msg_type"]
        sequence_id = Websocketres["sequence_id"]
        rangetime = str(int(time.time()))
        num = rangetime[-4:]
        ACKdata = {
            "msg_type": "message_ack",
            "ack_msg_type": msg_type,
            "version": "v1.0.1",
            "ack_seq_id": sequence_id,
            "sequence_id": num,
            "result": "ok"
        }
        if qos_type == 1:
            ws.send(json.dumps(ACKdata))
            print u"ACK Sent"
    else:
        print u"No ack"
    print u"on_message completed."

    return message

def on_error(ws, error):
    print error

def on_close(ws):
    print "### closed ###"

def on_open(ws):
    # 6、session_id检查
    bodydate = {"msg_type": "hub_activate",
                "qos": 2,
                "sequence_id": "123",
                "version": "v2.0",
                "request": {
                    "hub_vendor": hub_vendor,
                    "hub_mac": hub_mac,
                    "key": "lenovo",
                    "hub_type": hub_type
                }
                }
    ws.send(json.dumps(bodydate))
    result = json.loads(ws.recv())
    hub_id = result["data"]["hub"]["hub_id"]
    hub_key = result["data"]["hub"]["hub_key"]

    hufv_databy = {"msg_type": "hub_update_firmware",
                   "qos": 2,
                   "sequence_id": "123",
                   "version": "v2.0",
                   "request": {
                       "version": 4010,
                       "os_version": "11.1.46",
                       "ip": "61.135.169.73"
                   }
                   }

    ws.send(json.dumps(hufv_databy))
    result = json.loads(ws.recv())
    #print result
    # thread = MyThread(1,"thread-1",100)
    # thread.setDaemon(True)
    # thread.start()
    return hub_id , hub_key

class MyThread(threading.Thread):
    def __init__(self, threadID, name,counter):
     threading.Thread.__init__(self)
     self.threadID = threadID
     self.name = name
     self.counter = counter

    def run(self):
        keepalive(self.name,5,self.counter)

def keepalive(name,delay,counter):
     while counter:
        print "Live package sent: %d" % counter
        time.sleep(delay)
        ws.send(json.dumps({"msg_type": "keepalive"}))
        result=ws.recv()
        on_message(ws,result)
        on_error(ws,result)
        counter -=1

#1、hub websockets连接
url = "wss://" + domain + "/hub/comet?ver=v2.1&mac="+hub_mac
ws = websocket.create_connection(url,sslopt={"cert_reqs": ssl.CERT_NONE},)

hub_id,hub_key = on_open(ws)
time.sleep(10)
#print "Received '%s'" % result
#print hub_id