#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json,time
#time.sleep(2)
import Public,websockethub
import unittest

class updatehubsn(unittest.TestCase):

    def setUp(self):
        self.ws = websockethub.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsh, message):
        # print "hub %s" % message
        if "update_hub_sn" in message:
            Websocketresh = json.loads(message)
            resultassert = Websocketresh["result"]
            code = Websocketresh["data"]["code"]
            self.assertEqual(resultassert, u"ok")
            self.assertEqual(code, u"0")
            result = "true"

        else:
            result = "fales"

        return result

    def test_Udhubsn(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""

        wsh = self.ws
        testdata = Public.updatehubsn_databy
        print testdata
        wsh.send(json.dumps(testdata))

        for i in range(15):
            message = wsh.recv()
            #print u"ssssssmessage %s" % message

            result = self.on_message(wsh, message)
            print u"result %s " % result
            #time.sleep(2)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.ws.close()

if __name__ == "__main__":

    unittest.main()