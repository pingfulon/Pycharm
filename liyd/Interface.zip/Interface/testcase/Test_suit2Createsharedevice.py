#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
from Data import *
from createsharecode import share_code


class sharedevice(unittest.TestCase):

    def setUp(self):
        self.requrl_accept_share_code = "https://" + domain + "/v2.0/share/accepting_by_share_code"
        self.requrl_delete_share_code = "https://" + domain + "/v2.0/share/delete_share_code"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Acceptsharecode(self):
        requrl_accept_share_code = self.requrl_accept_share_code

        headerdata = Public.Httpheaders
        accept_share_code_testdata = {"share_code":share_code}
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="POST", url=requrl_accept_share_code, headers=headerdata, body=json.dumps(accept_share_code_testdata))
        response = conn.getresponse()

        # 获取数据
        resaccsharecode = json.loads(response.read())
        code = resaccsharecode["code"]
        print resaccsharecode

        if code == u"0":
            print u"成功返回"
            status = True
        elif code == u"61001":
            print u"失败 share_code 无效"
            status = False
        elif code == u"61409":
            print u"失败 不能分享给自己"
            status = True
        else:
            print u"其他错误"
            status = False
        self.assertTrue(status)

        self.assertEqual(code,u"61409")

    def test_Deletesharecode(self):
        requrl_delete_share_code = self.requrl_delete_share_code
        headerdata = Public.Httpheaders
        delete_share_code_testdata = {"share_code": share_code}
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="POST", url=requrl_delete_share_code, headers=headerdata, body=json.dumps(delete_share_code_testdata))
        response = conn.getresponse()

        # 获取数据
        resdelsharecode = json.loads(response.read())
        code = resdelsharecode["code"]
        print resdelsharecode
        self.assertEqual(code,u"0")

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main(verbosity=2)
