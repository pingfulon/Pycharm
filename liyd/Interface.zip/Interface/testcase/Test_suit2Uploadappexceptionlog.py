#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json,time
#time.sleep(2)
import Public
import websockethub
import unittest

class uploadappexceptionlog(unittest.TestCase):

    def setUp(self):
        print "1"
        self.wsh = websockethub.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsh, message):
        # print "hub %s" % message
        if "upload_app_exception_log" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            self.assertEqual(code, u"0")
            result = "true"

        else:
            result = "fales"

        return result

    def test_Upappexceptionlog(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""
        print "2"

        wsh = self.wsh
        hub_id = websockethub.hub_id
        testdata = Public.uploadappexceptionlog_databy
        print testdata
        wsh.send(json.dumps(testdata))
        for i in range(15):
            message = wsh.recv()
            #print u"message %s" % message

            result = self.on_message(wsh, message)
            print u"result %s " % result
            #time.sleep(5)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":

    unittest.main()