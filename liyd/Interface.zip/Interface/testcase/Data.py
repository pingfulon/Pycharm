#! /usr/python/bin
# -*- coding=UTF-8 -*-

#****************************变量*******************************
domain = "chnshp.lenovo.com.cn"
#domain = "pvtshp.lenovomm.com"
#domain = "cnpvtshp.lenovomm.com"
#domain = "deviot.lenovomm.com"
#domain = "cnpvttest.lenovo.com.cn"
#domain = "eupvt.lenovo.com.cn"
pcdomain = "sho.lenovo.com.cn"
user_name = "18910862390"
lenovo_id = "10106100677"
mac = "ABCDABCDABCD"
hub_mac = "ABCDABCDABCE"
hub_vendor = "lenovo EDUi"
hub_name = "联想智能音箱"
hub_type = "1000004"
gadget_vendor = "Lenovo Smart Speaker"
gadget_mac = "923w4567t89100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
gadget_type_id="200001"
gadget_name = "联想智能音箱"
