#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json,time
import Public
import websockethub
import unittest
from creategadget import gadget_id

class getaccesslogs(unittest.TestCase):

    def setUp(self):
        self.wsh = websockethub.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsh, message):

        if "get_access_logs" in message:
            Websocketresh = json.loads(message)
            getresult = Websocketresh["result"]
            self.assertEqual(getresult, u"ok")
            result = "true"

        else:
            result = "false"

        return result

    def test_Gaccesslog(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""
        wsh = self.wsh
        testdata = Public.getaccesslogs_databy(str(gadget_id))
        print testdata
        wsh.send(json.dumps(testdata))
        for i in range(15):
            message = wsh.recv()
            print  message

            result = self.on_message(wsh, message)
            print  result
            time.sleep(1)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()

if __name__ == "__main__":
    unittest.main()