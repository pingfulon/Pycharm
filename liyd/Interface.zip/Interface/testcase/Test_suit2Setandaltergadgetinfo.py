#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
from Data import *
from creategadget import gadget_id


class setandaltergadgetinfo(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/gadget/"+str(gadget_id)+"?ts=11111"
        print str(gadget_id)
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Sagadgetinfo(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        requrl = self.requrl

        headerdata = Public.Httpheaders
        testdata = Public.setandaltergadgetinfo_databy
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="PUT",url=requrl,body=json.dumps(testdata),headers = headerdata)
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        code = res["code"]
        print res
        if code == u"0":
            print u"成功返回"
            status = True
        elif code == u"43004":
            print u"失败：Gadget 不存在"
            status = False
        elif code == u"43003":
            print u"失败:没有权限操作此 Gadget"
            status = False
        else:
            print u"其他错误"
            status = False
        self.assertTrue(status)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
