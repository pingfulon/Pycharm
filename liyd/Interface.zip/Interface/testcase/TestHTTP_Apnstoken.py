#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
import httpclient
from Data import *

user_id= httpclient.user_id
class apnstoken(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/ios/apns_token"
        self.delrequrl = "https://" + domain + "/v2.0/ios/delete_token"
        self.headerdata = Public.Httpheaders
        self.test_data = Public.apnstoken_databy
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_upApnstoken(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="POST",url=self.requrl,body=json.dumps(self.test_data) ,headers = self.headerdata)
        response = conn.getresponse()
        print response.status
        #获取数据
        res= json.loads(response.read())
        code = res["code"]
        print res
        self.assertEqual(code , u"0")

    def test_delApnstoken(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="DELETE",url=self.delrequrl,body=json.dumps(self.test_data) ,headers = self.headerdata)
        response = conn.getresponse()
        print response.status
        #获取数据
        res= json.loads(response.read())
        code = res["code"]
        print res
        self.assertEqual(code , u"0")

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
