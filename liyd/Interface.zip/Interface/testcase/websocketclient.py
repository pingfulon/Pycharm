#!/usr/bin/python
# -*- coding:UTF-8 -*-

import json
import threading
import time
import ssl
import websocket

import Public
import httpclient
from Data import *


def on_message(ws, message):
    print "client %s" %message
    if "qos_type" in message:
        Websocketres = json.loads(message)
        qos_type = Websocketres["qos_type"]
        msg_type = Websocketres["msg_type"]
        sequence_id = Websocketres["sequence_id"]
        rangetime = str(int(time.time()))
        num = rangetime[-4:]
        ACKdata = {
            "msg_type": "message_ack",
            "ack_msg_type": msg_type,
            "version": "v1.0.1",
            "ack_seq_id": sequence_id,
            "sequence_id": num,
            "result": "ok"
        }
        if qos_type == 1:
            ws.send(json.dumps(ACKdata))
            print u"ACK Sent"
    else:
        print u"No ack"
    print u"on_message completed."

def on_error(ws, error):
    print error

def on_open(ws):
    bodydate = Public.websocketclient_dateby
    ws.send(json.dumps(bodydate))
    print "thread terminating..."
    # 创建新线程
    #thread = MyThread(1, "Thread-1", 100)
    #thread.setDaemon(True)
    # 开启线程
    #thread.start()
    print "thread terminated"

class  MyThread( threading.Thread):
    def __init__(self, threadID , name,counter):
         threading.Thread.__init__(self)
         self.threadID = threadID
         self.name = name
         self.counter = counter

    def run(self):
        keepalive(self.name,5,self.counter)

def keepalive(name,delay,counter):
     # 维持心跳
     while counter:
        print counter
        time.sleep(delay)
        ws.send(json.dumps({"mt": "k"}).decode("utf-8"))
        result=ws.recv()
        on_message(ws,result)
        on_error(ws,result)
        counter -=1




#websocket.enableTrace(True)
#5、client websockets连接
user_id = httpclient.user_id
session_id = httpclient.session_id
#print Public.websocketclient_header
url = "wss://" + domain + "/client/comet?user_id=" + Public.user_id + "&mac="+mac+"&locale=zh&ver=v2.0"
ws = websocket.create_connection(url, header = Public.websocketclient_header,sslopt={"cert_reqs": ssl.CERT_NONE})
on_open(ws)


