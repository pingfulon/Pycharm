#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json, time
import Public
import websocketclient, websockethub
import unittest


class deleteservicestatus(unittest.TestCase):
    def setUp(self):
        self.wsh = websockethub.ws
        self.wsc = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def con_message(self, wsc, message):
        # print "hub %s" % message
        if "delete_service_status" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            if code == u"0":
                print u"成功返回0"
                status = True
            elif code == u"63404":
                print u"上报失败 service_key 不存在"
                status = False
            elif code == u"63400":
                print u"失败，错误的请求（ Data数据格式不对）"
                status = False
            else:
                print u"其他错误"
                status = False

            self.assertTrue(status)
            result = "true"

        else:
            result = "false"

        return result

    def hon_message(self, wsh, message):
        # print "hub %s" % message
        if "delete_service_status" in message:
            Websocketresh = json.loads(message)
            delete_service_status = Websocketresh["msg_type"]
            print u"hub返回成功"
            self.assertEqual(delete_service_status,u"delete_service_status")

            result = "true"

        else:
            result = "false"

        return result

    def test_Delservicestatus(self):
        # *****************************************设置hub信息*********************************************
        u"""设置hub信息"""
        wsh = self.wsh
        wsc = self.wsc
        testdata = Public.deleteservicestatus_databy
        print testdata
        wsc.send(json.dumps(testdata))
        for i in range(15):
            message = wsh.recv()
            print u"sssssssmessage %s" % message

            result = self.hon_message(wsh, message)
            print u"result %s " % result
            #time.sleep(5)
            if result == "true":
                statush = True
                break
            else:
                statush = False
                continue

        self.assertTrue(statush)

        for i in range(15):
            #time.sleep(2)
            message = wsc.recv()
            #print u"ccccccmessage %s" % message

            result = self.con_message(wsc, message)
            #print u"result %s " % result
            #time.sleep(1)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()

if __name__ == "__main__":
    unittest.main()