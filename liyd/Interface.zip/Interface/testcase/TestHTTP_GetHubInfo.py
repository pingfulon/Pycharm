#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import httpclient,websockethub
from Data import *
import Public
import unittest
import json

class gethubinfo(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/hub/" + websockethub.hub_id + "?ts=11111"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Ghubinfo(self):
        #*******************************************获取hub信息************************************************
        u"""获取hub信息"""
        requrl = self.requrl

        headerdata = Public.Httpheaders

        conn = httplib.HTTPSConnection(domain)
        conn.request(method="GET",url=requrl,headers = headerdata)
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        print res
        code = res["code"]
        hub_id = res["hub"]["hub_id"]
        if code == "0"and hub_id != "":
            statu = True
        else:
            statu = False
        self.assertTrue(statu)
        #self.assertEqual(hub_id,"hub_id")
        #self.assertEqual(user_id,"user_id")

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
