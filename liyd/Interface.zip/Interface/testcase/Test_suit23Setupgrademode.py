#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json,time
import Public
import websockethub
import unittest

class setupgrademode(unittest.TestCase):

    def setUp(self):
        self.wsh = websockethub.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsh, message):
        # print "hub %s" % message
        if "set_upgrade_mode" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            if code == u"0":
                print u"成功返回"
                status = True
            elif code == u"42004":
                print u"上报失败 hub 不存在"
                status = False
            else:
                print u"其他错误"
                status = False

            self.assertTrue(status)
            result = "true"

        else:
            result = "false"

        return result

    def test_Supgrademode(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""
        wsh = self.wsh
        hub_id = websockethub.hub_id
        testdata = Public.setupgrademode_databy
        print testdata
        wsh.send(json.dumps(testdata))
        for i in range(15):
            message = wsh.recv()
            #print u"sssssssmessage %s" % message

            result = self.on_message(wsh, message)
            #print u"result %s " % result
            #time.sleep(2)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()