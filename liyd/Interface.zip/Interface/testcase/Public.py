#! /usr/python/bin
# -*- coding=UTF-8 -*-

import base64
import hashlib
import httplib
import hmac
import json
import time
import string
import random
import httpclient
import websockethub
from urllib import urlencode
from Data import *

#*************************************变量**********************************
#global user_id,session_id
user_id = httpclient.user_id.encode("utf-8")
session_id = httpclient.session_id.encode("utf-8")
hub_id = websockethub.hub_id
ws = websockethub.ws
unixtime = str(int(time.time()))
data = time.strftime('%Y%m%d',time.localtime(time.time()))


#*************************************方法***********************************

def binding():
    #**********************************7、client 绑定hub***********************************
    bdurl="https://" + domain + "/v2.0/binding/hub?ts=0"
    conn = httplib.HTTPSConnection(domain)
    conn.request("POST",bdurl,json.dumps(bddata), Httpheaders )
    response3 = conn.getresponse()

    #接收数据并打印
    res3= json.loads(response3.read())
    code = res3["code"]
    #bingdinghub_id = res3["hub"]["hub_id"]
    #hub_id = str(bingdinghub_id)
    #print res3
    return code



def gethublist():
    #***************************************获取hub信息*************************************
    requrl = "https://" + domain + "/v2.0/hubs?ts=0"

    conn = httplib.HTTPSConnection(domain)
    conn.request(method="GET",url=requrl,headers = Httpheaders)
    response6 = conn.getresponse()

    #接收数据并打印
    res6= json.loads(response6.read())
    return res6


def unbind(hub_id):
    #***************************************8、client 解绑hub**************************************
    #hub_id=gethublist()
    jburl="https://" + domain + "/v2.0/binding/hub/" + hub_id + "?ts=0"

    conn = httplib.HTTPSConnection(domain)
    conn.request("DELETE",jburl,body=None,headers=Httpheaders )
    response5 = conn.getresponse()

    #接收数据并打印
    res5= json.loads(response5.read())
    code = res5["code"]
    return code

def creategadget():
        binding()
        ws.send(json.dumps(cg_databy))
        #time.sleep(5)
        result = json.loads(ws.recv())
        #print "result %s" % result
        return result


def minicreategadget():
    binding()
    ws.send(json.dumps(minicreategadget_databy))
    result = json.loads(ws.recv())
    return result

def createroom():
    requrl = "https://" + domain + "/v2.0/room?ts=11111"
    conn = httplib.HTTPSConnection(domain)
    conn.request(method="POST", url=requrl, headers=Httpheaders, body=json.dumps(createroom_databy))
    response = conn.getresponse()
    # 获取数据
    res = json.loads(response.read())
    #print res
    return res

def getsig():
    himalayantimestamp = str(int(round((time.time() * 1000))))
    app_key = "c53171eb3f9f4c4ea0da51a850a1c903"
    himalayannonce = string.join(
        random.sample(['z', 'y', 'x', 'w', 'v', 'u', 't', 's', 'r', 'q', 'p', 'o', 'n', 'm', 'l', 'k', 'j', 'i', 'h'
                          , 'g', 'f', 'e', 'd', 'c', 'b', 'a', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
                      10)).replace(' ', '')
    app_screct = "d91356c6b50a0cadcf712305f610c475"

    sig0 = {"client_id" : app_key,
            "device_id" : "606720BD5695",
            "grant_type": "client_credentials",
            "nonce": himalayannonce,
            "timestamp": himalayantimestamp
            }
    s = sorted(sig0.iteritems(), key=lambda asd:asd[0],reverse=False)

    sig1=[]
    for i in range(len(s)):
        j = 0
        sig1.append(s[i][j])
        sig1.append("=")
        sig1.append(s[i][j + 1])
        if i != len(s) - 1:
            sig1.append("&")

    sig1 = str(sig1).replace(',', '').replace(' ', '').replace('[', '').replace(']', '').replace("'", '')
    sig2 = base64.b64encode(sig1)
    sig3=hmac.new("d91356c6b50a0cadcf712305f610c475",sig2,hashlib.sha1).digest()
    m = hashlib.md5()
    m.update(sig3)
    sig = m.hexdigest()
    return sig

def gethimalayanaccesstoken():
    himalayantimestamp = str(int(round((time.time() * 1000))))
    app_key = "c53171eb3f9f4c4ea0da51a850a1c903"
    himalayannonce = string.join(
        random.sample(['z', 'y', 'x', 'w', 'v', 'u', 't', 's', 'r', 'q', 'p', 'o', 'n', 'm', 'l', 'k', 'j', 'i', 'h'
                          , 'g', 'f', 'e', 'd', 'c', 'b', 'a', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
                      10)).replace(' ', '')
    sig = getsig()
    himalayandomain = "api.ximalaya.com"
    requesturl = "http://api.ximalaya.com/oauth2/secure_access_token"
    headerdata = {"Content-Type": "application/x-www-form-urlencoded"}
    bodydata = {"client_id": app_key,
                "device_id": "606720BD5695",
                "grant_type": "client_credentials",
                "nonce": himalayannonce,
                "timestamp": himalayantimestamp,
                "sig": sig
                }
    connect = httplib.HTTPConnection(himalayandomain)
    connect.request(method="POST", url=requesturl, body=urlencode(bodydata), headers=headerdata)
    response = connect.getresponse()

    # 接收数据并打印
    res = json.loads(response.read())
    #print res
    access_token = res["access_token"]
    access_token = access_token.encode('utf-8')
    print access_token
    return access_token

def getpcheaderdata():
    nonce = string.join(
        random.sample(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                       '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],11)).replace(' ', '')
    app_id = "pc"
    app_key = "pc"

    l = nonce+app_id+app_key+unixtime
    Tstr = l[2:-2]
    m = hashlib.md5()
    m.update(Tstr)
    pctoken = m.hexdigest()
    pcheaderdata = {"app_id": app_id,
        "app_key": app_key,
        "nonce": nonce,
        "token": pctoken,
        "timestamp": unixtime,
        "lenovo_id": lenovo_id
                    }

    return pcheaderdata


#**************************报文内容******************************

Httpheaders = {
            "x-lenovows-userkey" : user_id,
            "octopus_sid" : session_id
}

bddata = {"hub_vendor": hub_vendor,
              "hub_mac": hub_mac,
              "hub_name": hub_name,
              "user_id": user_id
              }


Httpbody ={
   "app_ver":"3052",
   "hub_mac":hub_mac,
   "hub_vendor":hub_vendor,
  # "app_ver":"1",
   "os_type":"hub",
   "device_model":"0",
   "serival_number":"00000010"
    }
aui_databy = {"user_info":"x1x1",
                "push_msg_flag":True,
                "nick_name":"nicheng",
                "img_url":"touxiang url",
                "locale":"zn"
                }
shi_databy = {"hub_info":"x2x2",
                    "room_id":"xxx",
                    "home_id":"xx",
                    "hub_name":"x4x4"
                    }
websocketclient_dateby = {"msg_type": "check_sid",
                "version": "v1.0.1",
                "qos": 1,
                "sequence_id": "94E979F934AB00861479476205",
                "request": {"sid": session_id}
                }
websocketclient_header = {"x-lenovows-userkey":user_id}



hufv_databy= {"msg_type": "hub_update_firmware",
            "qos": 2,
            "sequence_id": "123",
            "version": "v2.0",
            "request": {
                "version":4010,
                "os_version": "11.1.46",
                "ip":"61.135.169.73"
            }
        }

cg_databy = {
            "msg_type": "create_gadget",
            "qos": 2,
            "sequence_id": "yinyandi123",
            "version": "v2.0",
            "request": {
                "gadget_vendor": gadget_vendor,
                "gadget_mac": gadget_mac,
                "gadget_type_id": gadget_type_id
            }
        }

gmac =string.join(random.sample(['z','y','x','w','v','u','t','s','r','q','p','o','n','m','l','k','j','i','h'
                                         ,'g','f','e','d','c','b','a','0','1','2','3','4','5','6','7','8','9'],
                                     12)).replace(' ','')
testcg_databy = {
            "msg_type": "create_gadget",
            "qos": 2,
            "sequence_id": "yinyandi123",
            "version": "v2.0",
            "request": {
                "gadget_vendor": gadget_vendor,
                "gadget_mac": gmac+"00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
                "gadget_type_id": gadget_type_id
            }
        }

hbds_databy={
    "msg_type": "hub_bind_status",
    "qos": 2,
    "sequence_id": "yinyandi123",
    "version": "v2.0",
    "request": {
        "hub_id": hub_id
    }
}

hibd_databy={
    "msg_type": "hub_is_binded",
    "sequence_id": "9ba275ca600f57f11b02ae70d8bf4580",
    "qos_type":1 ,
    "qos" : 1,
    "version": "v2.0",
    "request": {
        "user_id": user_id,
        "hub_id":hub_id
    }
}

nlu_result1={"input":"",
             "vendor":"aispeech",
               "device_time":unixtime,
               "voicefileurl":"https://deviot.lenovomm.com/static/lxw/test/20170627/20170627143019201706271430180021.mp3",
              "reply":""}


def updateaccesslog_databy(gadget_id):
    udal_databy = {
        "msg_type": "update_access_log",
        "qos": 2,
        "ns": "access_log",
        "sequence_id": "yinyandi1234",
        "version": "v2.0",
        "request": {
            "user_id": "",
            "gadget_id": gadget_id,
            "user_time": unixtime,
            "text": "播放一首歌",
            "url": "https://deviot.lenovomm.com/static/lxw/test/20170626/20170626163702201706261637020024.mp3",
            "nlu_result":json.dumps(nlu_result1,ensure_ascii=False),
            "dispatcher":{"" : ""}

        }
    }
    return udal_databy

updatehubsn_databy = {
  "msg_type": "update_hub_sn",
  "qos": 2,
  "sequence_id": "12344",
  "version": "v2.0",
  "ns": "hub_sn",
  "request": {
    "sn": "23123243"
  }
}

def updategadgetlist_databy(gadget_id):
    updategadgetlist_databy = {"msg_type":"update_gadget_list",
                             "version":"v1.0.1",
                             "sequence_id": "yinyandi123",
                             "request":{"hub_id":hub_id,"gadgets":[{"gadget_id":gadget_id,"status":True}]}
                    }
    return updategadgetlist_databy

def updategadgetattr_databy(gadget_id):
    updategadgetattr_databy = {
            "msg_type":"update_gadget_attr",
            "version":"v1.0.1",
            "sequence_id":"488D3640A82700291498544852",
            "request":{
            "gadget_id":gadget_id,
            "gadget_type_id":gadget_type_id,
            "attributes":[{
            "attribute_id":"0x10000004",
            "attr_time":unixtime,
            "value":["488D3640A827"]
                        }]
                    }
            }
    return  updategadgetattr_databy

updatehubstatus_databy={
        "msg_type":"update_hub_status",
        "version":"v1.0.1",
        "sequence_id":"488D3640A98600021498544844",
        "request":{
        "hub_id":hub_id,
        "main_service":1,
        "ble":0,
        "zigbee":0,
        "upnp":0,
        "Ip_local":"192.168.1.1"
                }
        }

minihubactivate_databy = {"msg_type": "hub_activate",
                "qos": 2,
                "sequence_id": "123",
                "ns":"octopus_hub_general",
                "version": "v2.0",
                "request": {
                    "hub_vendor": hub_vendor,
                    "hub_mac": hub_mac,
                    "key": "lenovo",
                    "hub_type": hub_type
                }
                }

minicreategadget_databy = {
            "msg_type": "create_gadget",
            "qos": 2,
            "ns":"octopus_hub_general",
            "sequence_id": "yinyandi1",
            "version": "v2.0",
            "request": {
                "gadget_vendor": gadget_vendor,
                "gadget_mac": gadget_mac,
                "gadget_type_id": gadget_type_id
            }
        }

def miniupdategadgetlist_databy(gadget_id):
    updategadgetlist_databy = {"msg_type":"update_gadget_list",
                             "version":"v1.0.1",
                             "ns": "octopus_hub_general",
                             "sequence_id": "yinyandi123",
                             "request":{"hub_id":hub_id,"gadgets":[{"gadget_id":gadget_id,"status":True}]}
                    }
    return updategadgetlist_databy

def miniupdategadgetattr_databy(gadget_id):
    updategadgetattr_databy = {
            "msg_type":"update_gadget_attr",
            "version":"v1.0.1",
            "sequence_id":"488D3640A82700291498544852",
            "request":{
            "gadget_id":gadget_id,
            "gadget_type_id":gadget_type_id,
            "attributes":[{
            "attribute_id":"0x10000004",
            "attr_time":unixtime,
            "value":["488D3640A827"]
                        }]
                    }
            }
    return  updategadgetattr_databy

miniupdatehubstatus_databy={
    "msg_type":"update_hub_status",
    "version":"v2.0",
    "ns":"octopus_hub_general",
    "qos":"1",
    "sequence_id": "1234567891",
    "request":{
        "main_service":1,    #1 正常， 0表示将要离线（重启服务等），如果以后有其它情况，可以丰富这个状态号
        "ble":1, #0 表示当前不支持， 1 表示当前支持
        "zigbee":1, #//0 表示当前不支持， 1 表示当前支持
        "zwave":1
        }
    }

userversionupdate_databy= {
    "app_ver":"v1.5.0.99.dev",
    "os_type":"android",
    "device_model":"huawei"

    }

resethub_databy = {
"msg_type":"reset_hub",
"version":"v1.0.1",
"sequence_id": 123,
"request":{
}
}

def gadgetcreategadget_databy(gadget_id):
    gadgetcreategadget = {
        "msg_type":"create_gadget",
         "version":"v1.0.1",
         "sequence_id": "yinyandi1",
         "gadget_id":gadget_id,
         "gadget_type_id":gadget_type_id,
         "notification":""
         }
    return  gadgetcreategadget

setandaltergadgetinfo_databy = {
        "room_id":"05003",
        "gadget_info":"",
        "client_data":"",
        "gadget_name":"智能音箱设备",
        "push_msg_flag":True
        }


deletemember_databy = {"share_user_id":"bb8513ace4329d15fbcc83c330b04933",
                        "gadget_ids":[]}

def deletemembers_databy(gadget_id):
    deletemembers = {"share_user_id":[],
     "gadget_id":gadget_id}
    return deletemembers

memberqiutshare_databy = { "gadget_ids" : ["02777349f42a67dfb4cab4c621d14e5c67310832"] }

applysharedevice_databy = {"hub_mac": hub_mac,
                            "hub_vendor" : hub_vendor}

gadgetrulelogs_databy = {
                      "start_time" :"20170121105522",
                      "end_time":"20180101123343" ,
                      "num":"10"
                     }

eventslogs_databy = [{"event_source_type":"gadget"},{"event_source_type":"rule"}]

def eventlogs_databy(gadget_id):
    event_source_type = ["gadget","push_message","rule","msg_function","msg_activity","msg_system"]
    eventlogs = []
    data = {
            "source_id" :gadget_id,
            "start_time"  :"20150121105522",
            "end_time" :"20150110000000",
            "num":"10"
             }
    for i in range(6):
        bd = {}
        data["event_source_type"] = event_source_type[i]
        bd = data.copy()
        eventlogs.append(bd)
        #print eventlogs
    return eventlogs

createroom_databy = {"room_name":"主卧",
                    "home_id": "4369e26e0e24c9132d937eecabd85eae0a11e7c6"
                     }

apnstoken_databy = {
"token":"37a477ac2bf40279ddcd05279963c8755daf7c314f571c0958e45079fc3a3657"
}

weather_databy = {"local" : "zh",
            "city" : "beijing"}

commitcustomeropinions_databy = {
  "opinions":"颜色不好看，我喜欢柔和点的颜色。反应有点慢",
  "commit_items":["1","4"]
}



updata={"id":"fb034c602a6ca031ce82c110a7cbb614",
     "time": unixtime,
     "week":[],
     "gadget_id":"",
     "title":"",
     "valid":"0",
     "bell_time":600,
      "ext":"",
     }
uploadservicestatus_databy = {
        "msg_type": "update_service_status",
        "qos": 2,
        "ns":"service_status",
        "sequence_id": "94E979F935E1001415011389734",
        "version": "v2.0",
        "request": {
            "service_key": "0x00000006",
            "vendor":"0x00000001",
            "data":updata
        }
    }

getservicestatus_databy = {
        "msg_type": "get_service_status",
        "qos": 2,
        "ns":"service_status",
        "sequence_id": "94E979F9379900071501141383",
        "version": "v2.0",
        "request": {
            "service_key": "0x10000001",
            "vendor":"0x00000001",
        }
    }

deleteservicestatus_databy = {
        "msg_type": "delete_service_status",
        "qos": 2,
        "ns":"service_status",
        "sequence_id": "94E979F9379900071501141388",
        "version": "v2.0",
        "request": {
            "service_key": "0x10000001",
            "vendor":"0x00000001",
        }
    }

savemenu_databy = {
        "msg_type": "save_menu",
        "qos": 2,
        "ns":"collect_menu",
        "sequence_id": "94E979F9379900071501141399",
        "version": "v2.0",
        "request": {
            "service_key": "0x00000001",
            #"id":"93e9fc8149cb0e396ee7216d78855c94",
            "name":"天后",
        }
    }

deletemenu_databy = {
    "msg_type": "delete_menu",
    "qos": 2,
    "ns":"collect_menu",
    "sequence_id": "123",
    "version": "v2.0",
    "request": {
        "service_key": "0x00000001",
        "id":""

    }
}

ext={
   "duration": "3000",
   "picurl": "http://www.tupianurl.com",
   "singer": "周杰伦",
   "songname": "菊花台"
}


addcollect_databy={
    "msg_type": "add_collect",
    "qos": 2,
    "ns":"collect",
    "sequence_id": "hehehehehhehhehe123",
    "version": "v2.0",
    "request": {
        "service_key": "0x00000001",
        "vendor":"0x00000003",
        "item_ids":[{"item_id":"9919225", "ext":ext}]

    }
}

deletecollect_databy={
    "msg_type": "delete_collect",
    "qos": 2,
    "ns":"collect",
    "sequence_id": "hehehehehhehhehe123",
    "version": "v2.0",
    "request": {
        "service_key": "0x00000001",
        "vendor":"0x00000003",
        "ids":["372eb90f92be53bdb5ec9863ea6bf393"]

    }
}

getcollects_databy = {
        "msg_type": "get_collects",
        "qos": 2,
        "ns":"collect",
        "sequence_id": "123",
        "version": "v2.0",
        "request": {
            "service_key": "0x00000001",
            "vendor":"0x00000003",
            "user_id":user_id,

        }
    }

didinonce= "951392457121"
key = "0b77217ae7b8b075054ef15c4d61c141"
diditokenstr = didinonce+key+unixtime
intercepttoken = diditokenstr[1:-1]
m = hashlib.md5()
m.update(intercepttoken)
diditoken = m.hexdigest()

dididriver_databy = {
        "src_type" : "didi",
        "order_id" : "order0011477304471",
        "third_order_id" : "TXpFeU5UUTJNamt5TkE9PQ==",
        "lng" : "116.27773533182",
        "lat" : "40.052890331941",
        "driver_name" : "零师傅",
        "taxi_no" : "京D00096",
        "taxi_company" : "滴滴打车",
        "phone" : "18000000096",
        "nonce" : "951392457121",
        "timestamp" : unixtime,
        "token" : diditoken,
        "order_num" : "306",
        "praise_num" : "306"
        }

getservicethirdpartys_databy = {
    "msg_type": "get_service_thirdpartys",
    "qos": 2,
    "ns":"service_thirdparty",
    "sequence_id": "123",
    "version": "v2.0",
    "request": {
            "service_key" : "0x10000001",
            "vendor" : "0x00000001"
    }
}



def updatedevicelog_databy(gadget_id):
    context = {"ctx_type": "mobile", "operation": "play"}
    updatedevicelog = {
        "msg_type": "update_device_log",
        "qos": 0,
        "ns": "device_log",
        "sequence_id": "1234",
        "version": "v2.0",
        "msg_time": unixtime,
        "request": {
            "tr_user_id": "lenovo_id1",
            "gadget_id": gadget_id,
            "device_type": gadget_type_id, #gadget_type_id 或其他设备标记,ios,android
            "context_type": "mobile", #文本格式，按键，播放内容标题
            "context":json.dumps(context)  #string,复杂数据需要escape json特殊符号.key不能有中文。
        }
    }
    return updatedevicelog

def getaccesslogs_databy(gadget_id):
    getaccesslogs = {
        "msg_type": "get_access_logs",
        "qos": 1,
        "qos_type":1,
        "ns": "access_log",
        "sequence_id": "1234",
        "version": "v2.0",
        "request": {
            "user_id": user_id,
            "gadget_id": gadget_id,
            "count": 20,
            "begin_date": 0,
            "end_date": 0
        }
    }
    return getaccesslogs

nlu_result={"input":"今天北京天气怎么样",
                                   "vendor":"aispeech",
                                   "domain":"天气",
                                   "param":{"日期":data,"__act__":"request","__tgt__":"天气"},
                                   "device_time":1497345404}
def nluselect_databy():
    nluselect= {
                "msg_type":     "nlu_select",
                "ns":   "nlu_select",
                "qos":  0,
                "sequence_id":  "3CA06704D21F00081497345435",
                "version":      "v2.0",
                "request":      {
                        "request_id":   1,
                        "user_id":      "",
                        "gadget_id":   "e6133b6cdc4a5367927aeae91de3ef2f9d2919ed",
                        "actor":        "device",
                        "url":  "",
                        "text": "今天天气怎么样",
                        "nlu_result": json.dumps(nlu_result,ensure_ascii=False)
                    }
                }
    return nluselect

getaccounttoken_databy = {
    "msg_type": "get_account_token",
    "qos": 0,
    "ns": "public_account",
    "sequence_id": "1234",
    "version": "v2.0",
    "request": {
         }
}
def setfunctionjsonobject(gadget_id):
    jsonobj = { "id":"",#此 Id有值修改，空(null)为创建
             "gadget_id":gadget_id,
             "start_time" : "06:30",
             "end_time" : "23:00",
             "status":"true",# %%true 启用，false 禁用
             "ext":[],
             }
    return jsonobj

def setgadgetfunction_databy(gadget_id):
    setgadgetfunction = {
            "msg_type": "set_gadget_function",
            "qos": 2,
            "ns": "gadget_function",
            "sequence_id": "123",
            "version": "v2.0",
            "request": {
                "function_key": "0x10000001",
                "data": setfunctionjsonobject(gadget_id)
            }
        }
    return setgadgetfunction

def getgadgetfunction_databy(gadget_id,hub_id):
    getfunctionjsonobj = {"gadget_id":gadget_id ,
                        "hub_id":hub_id}
    getgadgetfunction = {
            "msg_type": "get_gadget_function",
            "qos": 2,
            "ns": "gadget_function",
            "sequence_id": "123",
            "version": "v2.0",
            "request": {
                "function_key": "0x10000001",
                "data": getfunctionjsonobj
            }
        }

    return getgadgetfunction

deletegadgetfunction_databy={
            "msg_type": "delete_gadget_function",
            "qos": 2,
            "ns":"gadget_function",
            "sequence_id": "123",
            "version": "v2.0",
            "request": {
                "function_key": "0x10000001",
                "condition":{ "id":"6ba0cae6276986fa70cca5e8eb6d4d97" }
            }
        }

thirdcheckclientupdate_databy = {
       "app_ver":"1002",
       "hub_mac":hub_mac,
       "hub_vendor":"lenovo EDUi",
       "os_type":"hub",
       "device_model":"0",
       "serival_number":"YK000001",
    }
Hubheader = {
    "x-lenovows-hubkey" : hub_id
}

thirddownloadresult_databy = {
       "hub_mac":hub_mac,
       "hub_vendor":hub_vendor,
       "version":"1.3",
       "os_type":"hub",
       "os_type_id":"1000004",
       "result":"success"
   }

thirdupdateresult_databy = {
       "app_ver":"1.3",
       "update_ver":"1.3",
       "hub_mac":hub_mac,
       "hub_vendor":hub_vendor,
       "os_type":"hub",
       "os_type_id":"1000004",
       "update_msg":"success",
       "error_json":"error message"
    }

setupgrademode_databy = {
        "msg_type": "set_upgrade_mode",
        "qos": 2,
        "ns":"ota",
        "sequence_id": "123",
        "version": "v2.0",
        "request": {
            "hub_id": hub_id,
            "auto":"true"

        }
    }

setupgradepermit_databy = {
        "msg_type": "set_upgrade_permit",
        "qos": 2,
        "ns":"ota",
        "sequence_id": "123",
        "version": "v2.0",
        "request": {
            "hub_id": hub_id,
            "upgrade_permit":"fales"

        }
    }



uploadappexceptionlog_databy = {
        "msg_type": "upload_app_exception_log",
        "qos": 2,
        "ns":"app_exception_log",
        "sequence_id": "123",
        "version": "v2.0",
        "request": {
            "type": "hub",
            "message":"this is an apple"
        }
    }

hublogupload_header = {
    "hub_type":hub_type,
    "hub_vendor":hub_vendor,
    "sn":"YK000001",
    "hub_mac":hub_mac

}

gadgettype_databy = {
  "id": "1000060",
  "type_id": "1000060",
  "class_ids": "0x0d11",
  "connect_type": "wifi",
  "locale": "zh",
  "ifttt_action": "false",
  "ifttt_attr": "false",
  "name": "联想智能电视网关",
  "push_msg_flag": "true",
  "time_created": "2017-8-9 10:44:47",
  "ttl": "60000",
  "description": "联想智能电视网关",
  "vendor": "Lenovo TV"
}
getuserfavour_databy = {
    "msg_type": "get_user_favour",
    "qos": 2,
    "ns":"interested_tag",
    "sequence_id": "yinyandi123098",
    "version": "v2.0",
}
setuserfavour_databy = {
    "msg_type": "set_user_favour",
    "qos": 2,
    "ns":"interested_tag",
    "sequence_id": "yinyandi123098",
    "version": "v2.0",
    "request": {
        "favour": ["读书","健身","旅游"]
    }
}
getdefaultfavour_databy = {
    "msg_type": "get_default_favour",
    "qos": 2,
    "ns":"interested_tag",
    "sequence_id": "yinyandi098765",
    "version": "v2.0",
    "request": {
    }
}
setdefaultdevice_databy = {
    "msg_type": "set_default_dev",
    "qos": 2,
    "ns":"user_profile",
    "sequence_id": "123",
    "version": "v2.0",
    "request": {
              "default_play_devid":"1234567",
              "default_video":"09876543"
            }
}


getdefaultdevice_databy = {
    "msg_type": "get_default_dev",
    "qos": 2,
    "ns":"user_profile",
    "sequence_id": "123",
    "version": "v2.0",
    "request": {

           }
}

sendcode_databy = {
    "msg_type": "send_code",
    "qos": 2,
    "ns":"pc_code",
    "sequence_id": "123",
    "version": "v2.0",
    "request": {
           "data":lenovo_id
    }
}

gethimalayanhistory_databy = {
    "msg_type": "get_himalayan_history",
    "qos": 2,
    "ns":"himalayan_history",
    "sequence_id": "123",
    "version": "v2.0",
    "request": {
               "user_id":user_id     #%%省略此参数查询当前用户的，也可以指定查询某人的喜马拉雅历史记录
    }
}
savehimalayanhistory_databy = {
    "msg_type": "save_himalayan_history",
    "qos": 2,
    "ns":"himalayan_history",
    "sequence_id": "123",
    "version": "v2.0",
    "request": {
        "play_history_records":
        [
            {
                "content_type": 1,
                "album_id":3160816,
                "album_title":"郭德纲",
                "album_cover_url_small":"http://fdfs.xmcdn.com/group16/M00/95/B6/wKgDbFY8HO3R9lV0AAPk",
                "track_id":12312,
                "track_title":"相声",
                "track_cover_url_small":"http://fdfs.xmcdn.com/group13/M03/BD/77",
                "track_duration":1271,
                "break_second":5108,
                "play_begin_at":1496213630000,
                "play_end_at":1496213630000

             },
             {
                "content_type":2,
                "radio_id":93,
                 "radio_name":"音乐",
                 "radio_cover_url_small":"http://fdfs.xmcdn.com/group6/M08/A9/12/wKgDh",
                "schedule_id":12345,
                 "program_name":"音乐1",
                "break_second":5108,
                "play_begin_at":1496213630000,
                "play_end_at":1496213630000

             }
        ]
    }
}

deletehimalayanhistory_databy = {
    "msg_type": "delete_himalayan_history",
    "qos": 2,
    "ns":"himalayan_history",
    "sequence_id": "123",
    "version": "v2.0",
    "request": {

        "delete_type" : "1",#|"2",1:表示全部删除,2：正常删除

        "play_history_records":
        [
            {
                "content_type": 1,
                "album_id":3160816,
                "track_id":12312,
                "break_second":5108,
                "deleted_at":1496213630000,
             },
             {
                "content_type":2,
                "radio_id":93,
                "schedule_id":12345,
                "break_second":5108,
                "deleted_at":1496213630000
             }
        ]
    }
}

getkuwohistory_databy = {
    "msg_type": "get_kuwo_history",
    "qos": 2,
    "ns":"kuwo_history",
    "sequence_id": "123",
    "version": "v2.0",
    "request": {
           }
}

savekuwohistory_databy = {
    "msg_type": "save_kuwo_history",
    "qos": 2,
    "ns":"kuwo_history",
    "sequence_id": "123",
    "version": "v2.0",
    "request": {
        "play_history_records":
          [{
            "id":"3160816",
            "song_name":"忘情水",
            "duration":381,
            "pic_url": "http://**** ",
            "singer": "刘德华"
           },

       {
            "id":"2",
            "song_name":"真的爱你",
            "duration":380,
            "pic_url": "http://**** ",
            "singer": "刘德华"
       }
     ]
    }
}

deletekuwohistory_databy = {
    "msg_type": "delete_kuwo_history",
    "qos": 2,
    "ns":"kuwo_history",
    "sequence_id": "123",
    "version": "v2.0",
    "request": {
         "delete_type": "1",#|"2",1:表示全部删除,2：正常删除
        "play_history_records": [ "12","23" ]
    }
}

getcountrysyncdata_databy = {
   "id":"8760282524ef8bead665dc4ace64c614",
   "lenovo_id":lenovo_id,
   "lenovo_token":"9876543210",
  }

badlenovoidgetcountrysyncdata_databy = {
   "id":"8760282524ef8bead665dc4ace64c614",
   "lenovo_id":"123456",
   "lenovo_token":"9876543210",
  }

setcountrysyncdata_databy = {
  "id":"8760282524ef8bead665dc4ace64c614",
  "lenovo_id":lenovo_id,
  "lenovo_token":"",
  "ext_data": {"domain_name":domain}
 }

badlenovoidsetcountrysyncdata_databy = {
  "id":"8760282524ef8bead665dc4ace64c614",
  "lenovo_id":"123456",
  "lenovo_token":"9876543210",
  "ext_data": {"domain_name":domain}
 }


pcmessagespeakercloud_databy = {
"lenovo_id" : lenovo_id,
"device_id" : "121324324353327567454353",
"device_name" : "联想PC",
"device_type" : 1,
"device_img" : "http://js.lenovo.com.cn/privilege/images/header_default/header_default_1.jpg",
"status" : "true"
}

pcmessageonoroffline_databy = {
    "device_id": "1b08a3c2fc4fe744090882b079e421a83fcced4d",
    "status": "1"
}

pcmessageadddevice_databy = {
"lenovo_id" : lenovo_id,
"device_id" : "121324324353327567454353",
"device_name" : "智能联想pc",
"device_type" : 1,
"device_img" : "http://js.lenovo.com.cn/privilege/images/header_default/header_default_1.jpg",
"status" : "true"
}

pcgetdevice_databy =  {   "device_type_id": "200001" }


pcpublicdevicesop_databy = {
  "device_id": "107ad22eef772d7f3e66ba9db95634d77a01fb4b",
  "class_id": "0x0004",
  " action_id ": "0x00048000",
  "param": {
    "status": "play",
    "serviceID": "0x00000001",
    "vendorID": "0x00000003",
    "mediaID": "892062",
    "updateplaylist": "1",
    "playmode": "4",
    "listtype": "3",
    "listid": "311352587",
    "listname": "超好听却冷门的中文歌"
  }
}

shoppingprotocol_databy = {
                        "data_ver":"13543345",
                        "type":"shopping",
                        "protocol_ver":"0",
                        "client_type":"android"
                        }

def pcdevicedeletepc_databy(gadget_id):

    pcdevicedeletepc = {
                        "lenovo_id" : lenovo_id,
                        "device_id" : gadget_id,
                        "device_type" :"20001"
                        }
    return pcdevicedeletepc

pcaccountmerge_databy = {
        "master_lenovo_id" : lenovo_id,
        "slave_lenovo_id" : "10047771282"
        }


himalayangetindexcontent_databy =   {
        "device_id": "606720BD5695",
        "access_token":"1214343242"
}

plugcheckupdateinfo_databy =  {
        "app_version": "app1.0.2",
        "plat_form":"IOS" ,
        "plugs_info":[
                                  {"gadget_type_id":gadget_type_id,"current_plug_version":"1000"},

                                ]
}