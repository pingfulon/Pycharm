#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
from Data import *


class getgadgettype(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/gadget_type?ts=11111"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Ggadgettype(self):
        #*******************************************获取hub信息************************************************
        u"""获取hub信息"""
        requrl = self.requrl

        headerdata = Public.Httpheaders

        conn = httplib.HTTPSConnection(domain)
        conn.request(method="GET",url=requrl,headers = headerdata)
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        #print res
        code = res["code"]
        print code
        self.assertEqual(code,u"0")

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
