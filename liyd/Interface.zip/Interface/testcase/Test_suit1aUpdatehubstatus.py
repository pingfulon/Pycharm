#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json, time
#time.sleep(2)
import Public
import websocketclient, websockethub
import unittest


class updatehubstatus(unittest.TestCase):
    def setUp(self):
        self.wsh = websockethub.ws
        self.wsc = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsc, message):
        # print "hub %s" % message
        if "update_hub_status" in message:
            Websocketresh = json.loads(message)
            msg_type = Websocketresh["msg_type"]
            self.assertEqual(msg_type, u"update_hub_status")
            result = "true"

        else:
            result = "fales"

        return result

    def test_Udhubstatus(self):
        # *****************************************设置hub信息*********************************************
        u"""设置hub信息"""

        wsh = self.wsh
        testdata = Public.updatehubstatus_databy
        print testdata
        wsh.send(json.dumps(testdata))

        wsc = self.wsc
        for i in range(20):
            message = wsc.recv()
            #print u"ssssssmessage %s" % message

            result = self.on_message(wsc, message)
            print u"result %s " % result
            #time.sleep(2)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)



    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()

if __name__ == "__main__":

    unittest.main()