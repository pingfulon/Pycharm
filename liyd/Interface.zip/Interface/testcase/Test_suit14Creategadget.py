#!/usr/bin/python
# -*- coding:UTF-8 -*-

import websockethub
import json,unittest
import Public,time

class Creategadget(unittest.TestCase):

    def setUp(self):
        self.ws = websockethub.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsh, message):
        # print "hub %s" % message
        if "create_gadget" in message:
            Websocketresh = json.loads(message)
            print Websocketresh
            code = Websocketresh["data"]["code"]
            resultassert = Websocketresh["result"]
            self.assertEqual(resultassert, u"ok")
            self.assertEqual(code, u"0")
            result = "true"

        else:
            result = "false"

        return result

    def test_Cgadget(self):
        wsh = self.ws
        Public.binding()
        testbody = Public.testcg_databy
        #print testbody
        wsh.send(json.dumps(testbody))
        for i in range(15):
            message = wsh.recv()
            #print u"sssssssmessage %s" % message

            result = self.on_message(wsh, message)
            print u"result %s " % result
            #time.sleep(5)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.ws.close()

if __name__ == "__main__":
    unittest.main()
