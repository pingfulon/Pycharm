#!/user/python/bin
# -*- coding=UTF-8 -*-


import json
import websocketclient
import unittest
import Public
import time


class getuserfavour(unittest.TestCase):

    def setUp(self):
        self.ws = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsh, message):
        # print "hub %s" % message
        if "get_user_favour" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            self.assertEqual(code, u"0")
            result = "true"

        else:
            result = "false"

        return result

    def test_Getuserfavour(self):
        u"""Hub 更新firmware版本号"""
        wsc = self.ws
        bodydata = Public.getuserfavour_databy
        time.sleep(2)
        print bodydata
        wsc.send(json.dumps(bodydata))
        for i in range(15):
            message = wsc.recv()
            #print u"message %s" % message

            result = self.on_message(wsc, message)
            #print u"result %s " % result
            time.sleep(2)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()