#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
import httpclient
from Data import *

user_id= httpclient.user_id
class advertisement(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/weather"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Advertisement(self):
        #******************************************修改用户信息******************************************************

        testbody = Public.weather_databy
        conn = httplib.HTTPSConnection(domain)
        conn.request("POST",self.requrl,body=json.dumps(testbody),headers=Public.Httpheaders)
        response = conn.getresponse()
        print response.status
        res = json.loads(response.read())
        print res
        code = res["code"]
        if code == u"0":
            print u"返回成功"
            status = True
        elif code == u"1":
            print u"服务器忙"
            status = False
        else:
            print u"其他错误"
            status = False
        self.assertTrue(status)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
