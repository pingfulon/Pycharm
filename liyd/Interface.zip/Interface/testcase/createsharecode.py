#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json

import Public
from Data import *
from creategadget import gadget_id

requrl_share_device = "https://" + domain + "/v2.0/share/share_device"

headerdata = Public.Httpheaders
share_device_testdata ={
              "gadget_ids": [str(gadget_id)]
        }
conn = httplib.HTTPSConnection(domain)
conn.request(method="POST",url=requrl_share_device ,headers = headerdata,body= json.dumps(share_device_testdata))
response = conn.getresponse()
#获取数据
ressharedev= json.loads(response.read())
#print ressharedev
code = ressharedev["code"]
share_code = ressharedev["share_code"]
assert code == u"0"