#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
import websockethub
from Data import *


class sethubinfo(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://"+ domain +"/v2.0/hub/" + websockethub.hub_id + "?ts=11111"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Shubinfo(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""
        requrl = self.requrl
        test_data = Public.shi_databy
        headerdata = Public.Httpheaders
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="POST",url=requrl,body=json.dumps(test_data) ,headers = headerdata)
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        print res
        flag = res["flag"]
        code = res["code"]
        if flag=="0" and code == "0":
            print u"成功返回，flag正常"
            statu = True
        elif flag=="1" and code == "0":
            print u"成功返回，flag不一致"
            statu = True
        elif code == "42004" :
            print u"失败：Hub 不存在"
            statu = False
        elif code == "42003":
            print u"失败:没有权限操作此 Hub"
            statu = False
        else:
            statu = False
        self.assertTrue(statu)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()