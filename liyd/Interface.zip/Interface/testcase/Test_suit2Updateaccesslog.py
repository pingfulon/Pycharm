#!/usr/bin/python
# -*- coding:UTF-8 -*-


import json,unittest
import time
#time.sleep(2)
import Public,websockethub
from creategadget import gadget_id

class UpdateAccessLog(unittest.TestCase):

    def setUp(self):

        self.ws = websockethub.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self,wsh, message):
        #print "hub %s" % message
        if "update_access_log" in message:
            Websocketresh = json.loads(message)
            resultassert = Websocketresh["result"]
            code = Websocketresh["data"]["code"]
            self.assertEqual(resultassert, u"ok")
            self.assertEqual(code, u"ok")
            result = "true"

        else:
            result = "false"

        return result

    def test_Udaccesslog(self):

        wsh = self.ws

        testbody = json.dumps(Public.updateaccesslog_databy(str(gadget_id)),ensure_ascii=False)
        #print testbody
        wsh.send(testbody)
        for i in range(15):
            #time.sleep(5)
            message = wsh.recv()
            #print u"message %s" % message

            result = self.on_message(wsh, message)
            #print u"result %s " % result
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)



    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.ws.close()
if __name__ == "__main__":

    unittest.main()
