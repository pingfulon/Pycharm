#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest
import Public
import httpclient
from Data import *

user_id= httpclient.user_id
class advertisement(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/shopping_protocol"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_shoppingprotocol(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        requrl = self.requrl
        headerdata = Public.Httpheaders
        testdata = Public.shoppingprotocol_databy
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="POST",url=requrl,body=json.dumps(testdata),headers = headerdata)
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        code = res["code"]
        print res

        if code == u"0":
            print u"正常"
            statu = True
        elif code == u"404":
            print u"客户端协议版本号，如果上送的data_ver和云端数据data_ver相同返回404"
            statu = False
        else:
            print u"其他错误"
            statu = False
        self.assertTrue(statu)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
