#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json,time
import Public
import websocketclient,websockethub
import unittest

class addcollect(unittest.TestCase):

    def setUp(self):
        self.wsh = websockethub.ws
        self.wsc = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def con_message(self, wsc, message):
        # print "hub %s" % message
        if "add_collect" in message:
            Websocketresh = json.loads(message)
            add_collect =Websocketresh["msg_type"]
            print u"成功转发给client"
            self.assertEqual(add_collect,u"add_collect")
            result = "true"

        else:
            result = "false"

        return result

    def hon_message(self, wsh, message):
        # print "hub %s" % message
        if "add_collect" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            if code == u"0":
                print u"上报成功返回0"
                statush = True
            elif code == u"65404":
                print u"上报失败 menu_id 不存在"
                statush = False
            elif code == u"63400":
                print u"上报失败，错误的请求（ Data数据格式不对）"
                statush = False
            elif code == u"63404":
                print u"上报失败 service_key 不存在"
                statush = False
            elif code == u"63405":
                print u"歌单下歌曲超过限制"
                statush = False
            else:
                print u"其他错误"
                statush = False

            self.assertTrue(statush)
            result = "true"

        else:
            result = "false"

        return result

    def test_Addcollect(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""
        Public.binding()
        wsh = self.wsh
        wsc = self.wsc
        testdata = Public.addcollect_databy
        print testdata
        wsh.send(json.dumps(testdata))
        for i in range(15):
            message = wsh.recv()
            print u"sssssssmessage %s" % message

            result = self.hon_message(wsh, message)
            print u"result %s " % result
            #time.sleep(2)
            if result == "true":
                statush = True
                break
            else:
                statush = False
                continue

        self.assertTrue(statush)

        for i in range(15):
            message = wsc.recv()
            #print u"sssssssmessage %s" % message

            result = self.con_message(wsc, message)
            #print u"result %s " % result
            #time.sleep(1)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()

if __name__ == "__main__":
    unittest.main()