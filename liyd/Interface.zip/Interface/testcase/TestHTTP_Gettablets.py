#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
from Data import *


class gettablets(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/ts_ver"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Gettablets(self):
        #*******************************************获取hub信息************************************************
        u"""获取hub信息"""
        requrl = self.requrl

        headerdata = Public.Httpheaders

        conn = httplib.HTTPSConnection(domain)
        conn.request(method="GET",url=requrl,headers = headerdata)
        response = conn.getresponse()
        print response.status
        #获取数据
        res= json.loads(response.read())
        print res
        code = res["code"]
        if code == u"0":
            print u"返回成功"
            status = True
        elif code == u"44003":
            print u"没有权限"
            status = False
        else:
            print u"其他错误"
            status = False
        self.assertTrue(status)


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
