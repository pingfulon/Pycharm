#!/usr/bin/python
#coding:utf-8

import httplib
import json
from Data import *
import ssl

try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context

#4、client session_id获取
requrl = "https://" + domain + "/v2.0/fetch/user_key"
print requrl
test_data = {
    "id":"8760282524ef8bead665dc4ace64c614",
    "user_name":user_name,
    "lenovo_id":lenovo_id,
    "lenovo_token":"",
    "locale":"en",
    "app_ver":"v1.5.0.43.pvt",
    "os":"ios",
    "os_ver":"ss",
    "mac":mac
    }
conn = httplib.HTTPSConnection(domain)
conn.request(method="POST",url=requrl,body=json.dumps(test_data) )
response0 = conn.getresponse()
print response0.status
#接收数据并打印
res0= json.loads(response0.read())
#print res0

user_id = res0["user"]["user_id"]
session_id = res0["user"]["session_id"]

#print user_id


