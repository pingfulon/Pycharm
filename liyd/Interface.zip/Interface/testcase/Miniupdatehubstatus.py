#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json
import time
import unittest

import Public
import websocketclient
import websockethub


class updatehubstatus(unittest.TestCase):
    def setUp(self):
        self.wsh = websockethub.ws
        self.wsc = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Udhubstatus(self):
        # *****************************************设置hub信息*********************************************
        u"""设置hub信息"""

        wsh = self.wsh
        #wsc = self.wsc
        testdata = Public.miniupdatehubstatus_databy
        print testdata
        wsh.send(json.dumps(testdata))

        wsc = self.wsc
        time.sleep(10)
        result = wsh.recv()
        print "result %s" % result
        if "update_hub_status" in result:
            result = json.loads(result)
            msg_type = result["msg_type"]
            self.assertEqual(msg_type,u"update_hub_status")


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()

if __name__ == "__main__":
    unittest.main()