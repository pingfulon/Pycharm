#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
import httpclient
from Data import *

user_id= httpclient.user_id
class dididriver(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/pushReply"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Didriver(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        requrl = self.requrl
        headerdata = Public.Httpheaders
        test_data = Public.dididriver_databy
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="POST",url=requrl,body=json.dumps(test_data) ,headers = headerdata)
        response = conn.getresponse()
        print response.status
        #获取数据
        res= json.loads(response.read())
        #flag = res["flag"]
        #code = res["code"]
        print res

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
