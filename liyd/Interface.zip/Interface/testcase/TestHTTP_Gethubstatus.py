#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
import httpclient
from Data import *

user_id= httpclient.user_id
class gethubstatus(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/hubs/get_hub_status"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Ghubstatus(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        requrl = self.requrl

        headerdata = Public.Httpheaders
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="GET",url=requrl,headers = headerdata)
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        code = res["code"]
        print res
        self.assertEqual(code,u"0")




    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
