#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json,time
import Public
import websocketclient,websockethub
import unittest

class deletecollect(unittest.TestCase):

    def setUp(self):
        self.wsh = websockethub.ws
        self.wsc = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def con_message(self, wsc, message):
        # print "hub %s" % message
        if "delete_collect" in message:
            Websocketresc = json.loads(message)
            delete_collect = Websocketresc["msg_type"]
            if delete_collect == u"delete_collect":
                print u"成功转发给hub"
                result = "true"
            else:
                code = Websocketresc["data"]["code"]

                print code
                if code == u"0":
                    print u"上报成功返回0"
                    statusc = True
                elif code == u"63400":
                    print u"上报失败，错误的请求 Data数据格式不对"
                    statusc = False
                elif code == u"63404":
                    print u"上报失败 service_key 不存在"
                    statusc = False
                else:
                    print u"其他错误"
                    statusc = False

                self.assertTrue(statusc)
                result = "true"

        else:
            result = "false"

        return result

    def hon_message(self, wsh, message):
        # print "hub %s" % message
        if "delete_collect" in message:
            Websocketresh = json.loads(message)
            delete_collect = Websocketresh["msg_type"]
            if delete_collect == u"delete_collect":
                print u"成功转发给hub"
                result = "true"
            else:
                code = Websocketresh["data"]["code"]

                print code
                if code == u"0":
                    print u"上报成功返回0"
                    statush = True
                elif code == u"63400":
                    print u"上报失败，错误的请求 Data数据格式不对"
                    statush = False
                elif code == u"63404":
                    print u"上报失败 service_key 不存在"
                    statush = False
                else:
                    print u"其他错误"
                    statush = False

                self.assertTrue(statush)
                result = "true"

        else:
            result = "false"

        return result

    def test_HDelcollect(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""
        Public.binding()
        wsh = self.wsh
        wsc = self.wsc
        testdata = Public.deletecollect_databy
        wsh.send(json.dumps(testdata))
        for i in range(15):
            message = wsh.recv()
            #print u"sssssssmessage %s" % message
            result = self.hon_message(wsh, message)
            #print u"result %s " % result
            if result == "true":
                statush = True
                break
            else:
                statush = False
                continue

        self.assertTrue(statush)

        for i in range(15):
            message = wsc.recv()
            #print u"cccccmessage %s" % message

            result = self.con_message(wsc, message)
            #print u"result %s " % result

            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)



    def test_CDelcollect(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""
        Public.binding()
        wsc = self.wsc
        wsh = self.wsh
        testdata = Public.deletecollect_databy
        wsc.send(json.dumps(testdata))

        for i in range(15):
            message = wsh.recv()
            #print u"ccccccmessage %s" % message

            result = self.hon_message(wsh, message)
            #print u"result %s " % result
            #time.sleep(1)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)

        # time.sleep(5)
        for i in range(15):
            message = wsc.recv()
            #print u"sssssssmessage %s" % message

            result = self.con_message(wsc, message)
            #print u"result %s " % result
            #time.sleep(1)
            if result == "true":
                statush = True
                break
            else:
                statush = False
                continue

        self.assertTrue(statush)


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()

if __name__ == "__main__":
    unittest.main()