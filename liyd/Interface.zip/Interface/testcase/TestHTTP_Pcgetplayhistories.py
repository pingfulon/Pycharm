#!/user/python/bin
# -*- coding=UTF-8 -*-


import json
import httplib
import unittest
import Public
from Data import *

class messageadddevice(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/public/get/himalayan/play/histories"
        self.verificationErrors = []
        self.accept_next_alert = True


    def test_messageadddevice(self):
        u"""Hub 更新firmware版本号"""
        requrl = self.requrl

        headerdata = Public.getpcheaderdata()
        #testdata = ""
        #print testdata
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="POST", url=requrl, headers=headerdata)
        response = conn.getresponse()
        print response.status
        # 获取数据
        res = json.loads(response.read())
        print "res %s" % res
        code = res["code"]

        if code == u"0":
            print u"返回成功"
            status = True
        elif code == u"43003":
            print u"没有权限操作"
            status = False
        else:
            print u"其他错误"
            status = False

        self.assertTrue(status)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()