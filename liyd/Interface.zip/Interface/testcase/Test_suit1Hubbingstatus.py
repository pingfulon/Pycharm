#!/usr/bin/python
# -*- coding:UTF-8 -*-

import websockethub
import json, unittest
import Public,time

class Hubbindstatus(unittest.TestCase):

    def setUp(self):
        self.ws = websockethub.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsh, message):
        # print "hub %s" % message
        if "hub_bind_status" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            if code == u"0":
                print u"该hub首次被用户绑定"
                status = True
            elif code == u"42000":
                print u"该hub已被绑定"
                status = True
            elif code == u"42002":
                print u"hub没有被用户绑定"
                status = True
            else:
                print u"其他错误"
                status = False
            self.assertTrue(status)
            result = "true"

        else:
            result = "fales"

        return result

    def test_Hbindstatus(self):
        wsh = self.ws
        testbody = Public.hbds_databy
        wsh.send(json.dumps(testbody))

        for i in range(15):

            message = wsh.recv()
            print u"sssssmessage %s" % message

            result = self.on_message(wsh, message)
            print u"result %s " % result
            #time.sleep(2)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)


    def tearDown(self):

        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
