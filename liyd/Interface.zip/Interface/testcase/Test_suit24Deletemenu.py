#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json,time
import Public
import websockethub
import unittest

class deletemenu(unittest.TestCase):

    def setUp(self):
        self.wsh = websockethub.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsh, message):
        # print "hub %s" % message
        if "delete_menu" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            if code == u"0":
                print u"上报成功返回0"
                status = True
            elif code == u"63404":
                print u"上报失败 service_key 不存在"
                status = False
            elif code == u"63400":
                print u"上报失败，歌单id为空"
                status = False
            else:
                print u"其他错误"
                status = False

            self.assertTrue(status)
            result = "true"

        else:
            result = "false"

        return result

    def test_Deletemenu(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""
        Public.binding()
        wsh = self.wsh
        testdata = Public.deletemenu_databy
        print testdata
        wsh.send(json.dumps(testdata))
        for i in range(15):
            message = wsh.recv()
            #print u"sssssssmessage %s" % message

            result = self.on_message(wsh, message)
            #print u"result %s " % result
            #time.sleep(1)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()

if __name__ == "__main__":
    unittest.main()