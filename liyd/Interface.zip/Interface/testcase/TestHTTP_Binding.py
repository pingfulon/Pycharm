#! /usr/python/bin
# -*- coding=UTF-8 -*-

import Public
import unittest
import websockethub



class binding(unittest.TestCase):

    def setUp(self):
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_bind(self):
        u"""Hub绑定"""
        hub_id = []
        hubinfo = Public.gethublist()
        #print hubinfo
        code = hubinfo["code"]
        hub = hubinfo["hubs"]
        #print hub
        if code == u"0":
            if hub == []:
                print u"hub未绑定"
            else:
                for i in range(0,1):
                    hub_ids = hubinfo["hubs"][i]["hub_id"]
                    hub_id.append(hub_ids)
                    code = Public.unbind(hub_ids)
                    self.assertEqual(code,u"0")
                print u"hub绑定"
        else:
            print u"hub不存在或没有权限操作此hub"

        code = Public.binding()
        if code == u"0" or u"42409":
            result = True
        else:
            result = False
        self.assertTrue(result)
        hub = Public.gethublist()
        print hub
        hub_idm = hub["hubs"][0]["hub_id"]
        print hub_idm
        code = Public.unbind(hub_idm)
        self.assertEqual(code,u"0")

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__" :
    unittest.main()