#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import time
import unittest

import Public
from Data import *
from creategadget import gadget_id


class eventlogs(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/event/logs"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Eventlogs(self):
        #*******************************************获取hub信息************************************************
        u"""获取hub信息"""
        requrl = self.requrl
        headerdata = Public.Httpheaders
        testbody = Public.eventlogs_databy(str(gadget_id))
        for testdata in testbody:
            conn = httplib.HTTPSConnection(domain)
            conn.request(method="POST",url=requrl,headers = headerdata,body=json.dumps(testdata))
            response = conn.getresponse()
            print response.status
            #获取数据
            res=json.loads(response.read())
            print res
            code = res["code"]
            print code
            if code == u"0":
                print u"成功返回"
                status = True
            elif code == u"49104":
                print u"失败 source_id 不存在"
                status = False
            else:
                print u"其他错误"
                status = False
            self.assertTrue(status)
            time.sleep(2)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
