#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json, time
import Public
import websocketclient, websockethub
import unittest


class getservicestatus(unittest.TestCase):
    def setUp(self):
        self.wsc = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsc, message):
        # print "hub %s" % message
        if "get_service_status" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            if code == u"0":
                print u"成功返回0"
                status = True
            elif code == u"63404":
                print u"上报失败 service_key 不存在"
                status = False
            else:
                print u"其他错误"
                status = False

            self.assertTrue(status)
            result = "true"

        else:
            result = "fales"

        return result

    def test_Gservicestatus(self):
        # *****************************************设置hub信息*********************************************
        u"""设置hub信息"""

        wsc = self.wsc
        testdata = Public.getservicestatus_databy
        print testdata
        wsc.send(json.dumps(testdata))
        for i in range(15):

            message = wsc.recv()
            print u"message %s" % message

            result = self.on_message(wsc, message)
            print u"result %s " % result
            #time.sleep(2)
            if result == "true":
                status = True
                break
            else:
                status = False
                continue



        self.assertTrue(status)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()

if __name__ == "__main__":
    unittest.main()