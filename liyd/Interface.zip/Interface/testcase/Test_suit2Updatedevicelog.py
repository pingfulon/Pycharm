#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json,time
#time.sleep(2)
import Public
import websockethub
import unittest
from creategadget import gadget_id

class updatedevicelog(unittest.TestCase):

    def setUp(self):
        self.wsh = websockethub.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self,wsh, message):
        #print "hub %s" % message
        if "update_device_log" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            if code == u"0":
                print "返回成功"
                status = True
            elif code == u"201":
                print "返回失败"
                status = False
            else:
                print "其他错误"
                status = False

            self.assertTrue(status)
            result = "true"

        else:
            result = "fales"

        return result

    def test_Uddevicelog(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""
        wsh = self.wsh
        testdata = Public.updatedevicelog_databy(str(gadget_id))
        print testdata
        wsh.send(json.dumps(testdata))
        for i in range(15):
            #time.sleep(5)
            message = wsh.recv()
            print u"message %s" % message

            result = self.on_message(wsh, message)
            print u"result %s " % result
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()

if __name__ == "__main__":
    unittest.main()