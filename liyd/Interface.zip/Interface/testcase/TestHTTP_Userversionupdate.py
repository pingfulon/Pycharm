#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
from Data import *


class userversionupdate(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/user/version/update"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Uversionupdate(self):
        #*******************************************获取hub信息************************************************
        u"""获取hub信息"""
        requrl = self.requrl
        headerdata = Public.Httpheaders
        testdata = Public.userversionupdate_databy
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="POST",url=requrl,headers = headerdata,body=json.dumps(testdata))
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        print res
        code = res["code"]
        if code == u"0":
            print u"成功返回0 可以升级，但不是必须"
            status = True
        elif code == u"41005":
            print u"成功返回41005 强制用户升级"
            status = True
        elif code == u"304":
            print u"成功返回304, 已经是最新版本"
            status = True
        else:
            status = False
        self.assertTrue(status)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
