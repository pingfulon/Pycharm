#! /usr/python/binr
# -*- coding=UTF-8 -*-

from Public import *
import unittest
import json

class himalayancallback(unittest.TestCase):

    def setUp(self):
        lenovo_user_id = lenovo_id
        code = ""
        device_id = "0E6EFB7B-50AD-4D74-B5F1-5175146A523A"
        self.requrl = "https://" + domain + "/v2.0/partner/himalayan/callback?state="+lenovo_user_id+"" \
                            "&device_id="+device_id+"&code="+code
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_himalayacallback(self):
        #*******************************************获取hub信息************************************************
        u"""获取hub信息"""
        requrl = self.requrl

        headerdata = Httpheaders
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="GET", url=requrl, headers=headerdata)
        response = conn.getresponse()
        print response.status
        # 获取数据
        res = json.loads(response.read())
        print res


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
