#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
from Data import *

getroomid = Public.createroom()
room_id = getroomid["room_id"]
print room_id
class alteranddeleteroom(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/room/"+str(room_id)+"?ts=11111"
        self.headerdata = Public.Httpheaders
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Alterroom(self):
        #*******************************************修改room************************************************
        u"""修改room"""
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="POST",url=self.requrl,headers = self.headerdata,body=json.dumps({"room_name":"主卧"}))
        response = conn.getresponse()
        print response.status
        #获取数据
        res= json.loads(response.read())
        #print res
        code = res["code"]
        print code
        if code == u"0":
            print u"成功返回"
            status = True
        elif code == u"49003":
            print u"无操作room权限"
            status = False
        elif code == u"49004":
            print u"room_id不存在"
            status = False
        else:
            print u"其他错误"
            status = False
        self.assertTrue(status)
    def test_Deleteroom(self):
        #*******************************************删除room************************************************
        u"""删除room"""
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="DELETE", url=self.requrl, headers=self.headerdata)
        response = conn.getresponse()
        print response.status
        #获取数据
        res= json.loads(response.read())
        #print res
        code = res["code"]
        print code
        if code == u"0":
            print u"成功返回"
            status = True
        elif code == u"49003":
            print u"无操作room权限"
            status = False
        elif code == u"49004":
            print u"room_id不存在"
            status = False
        else:
            print u"其他错误"
            status = False
        self.assertTrue(status)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
