#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
from Data import *


class getuserinfo(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://"+domain+"/v2.0/user/get_user_info?ts=11111"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Guserinfo(self):
        #***************************************获取用户信息***************************************
        u"""获取用户已绑定的 Hub列表"""
        requrl = self.requrl

        headerdata = Public.Httpheaders
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="GET",url=requrl,headers = headerdata)#,body=json.dumps(test_data) )#,headers = headerdata)
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        print res
        user_id = res["user"]["user_id"]
        code = res["code"]
        if user_id != "" and code=="0":
            statu = True
        elif code == "304":
            statu = True
        else:
            statu = False
        self.assertTrue(statu)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()