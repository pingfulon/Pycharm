#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json
import time
import unittest

import Public
import websocketclient
import websockethub


class updategadgetlist(unittest.TestCase):

    def setUp(self):
        self.wsh = websockethub.ws
        self.wsc = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Udgadgetlist(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""
        getgadget_id = Public.minicreategadget()
        print getgadget_id
        gadget_id = str(getgadget_id["data"]["gadget_id"])
        print gadget_id
        wsh = self.wsh
        testdata = Public.miniupdategadgetlist_databy(gadget_id)
        wsh.send(json.dumps(testdata))
        wsc = self.wsc
        time.sleep(20)
        result = wsc.recv()
        print "result %s" %result
        if "gadget_status" in result:
            message = json.loads(result)
            msg_type = message["msg_type"]
            print msg_type
            self.assertEqual(msg_type, u"gadget_status")
        else:
            print "属性返回错误"


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()

if __name__ == "__main__":
    unittest.main()