#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json,time
import Public
import websocketclient,websockethub
import unittest

class resethub(unittest.TestCase):

    def setUp(self):
        self.wsh = websockethub.ws
        self.wsc = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsh, message):
        # print "hub %s" % message
        if "reset_hub" in message:
            Websocketresh = json.loads(message)
            reset_hub=Websocketresh["msg_type"]
            print u"result正确"
            self.assertEqual(reset_hub,u"reset_hub")

            result = "true"

        else:
            result = "false"

        return result

    def test_Resethub(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""
        Public.binding()
        wsc = self.wsc
        testdata = Public.resethub_databy
        wsc.send(json.dumps(testdata))
        wsh = self.wsh
        for i in range(15):
            message = wsh.recv()
            #print u"sssssmessage %s" % message

            result = self.on_message(wsh, message)
            #print u"result %s " % result
            #time.sleep(5)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()

if __name__ == "__main__":
    unittest.main()