#!/user/python/bin
# -*- coding=UTF-8 -*-

import json
import websocketclient
import unittest
import Public
import time

class deletekuwohistory(unittest.TestCase):

    def setUp(self):
        self.wsc = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsh, message):
        # print "hub %s" % message
        if "delete_kuwo_history" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            if code == u"0":
                    result = "true"
            elif code == u"6001":
                result = "false"
                print u"访问云端返回错误"

            self.assertEqual(result , "true")


        else:
            result = "false"

        return result

    def test_clientdeletekuwohistory(self):
        u"""Hub 更新firmware版本号"""
        wsc = self.wsc
        bodydata = Public.deletekuwohistory_databy
        time.sleep(2)
        print bodydata
        wsc.send(json.dumps(bodydata))
        for i in range(15):
            message = wsc.recv()
            print  message

            result = self.on_message(wsc, message)
            print u"result %s " % result
            time.sleep(2)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()