#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
import httpclient
from Data import *

user_id= httpclient.user_id
class alteruserinfo(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/user/" + user_id + "?ts=11111"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Auserinfo(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        requrl = self.requrl

        test_data = Public.aui_databy
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="PUT",url=requrl,body=json.dumps(test_data) )#,headers = headerdata)
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        flag = res["flag"]
        code = res["code"]
        print res

        if code == "0"and flag == "0":
            print u"正常"
            statu = True
        elif code == "0"and flag == "1":
            print u"flag = 1 不一致"
            statu = True
        else:
            statu = False
        self.assertTrue(statu)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
