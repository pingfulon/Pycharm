#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import time
from Data import *
import Public
import unittest
import json

class createroom(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/room?ts=11111"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Createroom(self):
        #*******************************************获取hub信息************************************************
        u"""获取hub信息"""
        res = Public.createroom()
        print "res %s" % res
        code = res["code"]
        print code
        if code == u"0":
            print u"成功返回"
            status = True
        elif code == u"49003":
            print u"无操作room权限"
            status = False
        elif code == u"48004":
            print u"home_id不存在"
            status = False
        else:
            print u"其他错误"
            status = False
        self.assertTrue(status)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
