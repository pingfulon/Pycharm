#!/usr/bin/python
# -*- coding:UTF-8 -*-

import websockethub
import json,unittest
import Public
import time


def on_message( wsh, message):
    # print "hub %s" % message
    if "create_gadget" in message:
        Websocketresh = json.loads(message)
        code = Websocketresh["data"]["code"]
        resultassert = Websocketresh["result"]

        result = "true"

    else:
        result = "false"

    return result

Public.binding()
ws = websockethub.ws
cg_databy = Public.cg_databy
ws.send(json.dumps(cg_databy))
for i in range(15):
    message = ws.recv()
    result = on_message(ws, message)
    if result == "true":
        statusc = True
        break
    else:
        statusc = False
        continue

getgadget = json.loads(message)
#print getgadget
gadget_id = getgadget["data"]["gadget_id"]
