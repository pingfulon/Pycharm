#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import unittest

import Public
from Data import *


class gadgetswithusers(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/share/gadgets_with_users"
        print self.requrl
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Gwithusers(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        requrl = self.requrl

        headerdata = Public.Httpheaders
        print headerdata
        #testdata = Public.memberqiutshare_databy
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="GET",url=requrl,headers = headerdata)
        response = conn.getresponse()
        print response.status
        #获取数据
        res= response.read()
        #code = res["code"]
        print res

        #self.assertEqual(code ,u"0")

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
