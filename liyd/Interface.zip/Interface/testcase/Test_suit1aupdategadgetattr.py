#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json,time
#time.sleep(2)
import Public
import websocketclient,websockethub
import unittest
from creategadget import gadget_id


class updategadgetattr(unittest.TestCase):

    def setUp(self):
        self.wsh = websockethub.ws
        self.wsc = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsc, message):
        # print "hub %s" % message
        if "update_gadget_attr" in message:
            Websocketresh = json.loads(message)
            msg_type = Websocketresh["msg_type"]
            print u"msgtype %s" % msg_type

            self.assertEqual(msg_type, u"update_gadget_attr")
            result = "true"

        else:
            result = "fales"

        return result

    def test_Udgadgetattr(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""

        wsh = self.wsh
        testdata = Public.updategadgetattr_databy(str(gadget_id))
        wsh.send(json.dumps(testdata))
        wsc = self.wsc
        for i in range(20):

            message = wsc.recv()
            #print u"sssssssmessage %s" % message

            result = self.on_message(wsc, message)
            #print u"result %s " % result
            #time.sleep(5)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()
        #time.sleep(10)

if __name__ == "__main__":

    unittest.main()