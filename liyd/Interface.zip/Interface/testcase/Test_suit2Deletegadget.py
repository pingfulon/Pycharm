#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
from Data import *
from creategadget import gadget_id


class deletegadget(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/logic/gadget/"+str(gadget_id)+"?ts=11111"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Deletegadget(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        requrl = self.requrl
        headerdata = Public.Httpheaders

        conn = httplib.HTTPSConnection(domain)
        conn.request(method="DELETE",url=requrl,headers = headerdata)
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        code = res["code"]
        print res
        self.assertEqual(code,u"0")

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
