#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
from Data import *
from creategadget import gadget_id


class deletemembers(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/share/delete_members"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Deletemembers(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        #Public.binding()
        requrl = self.requrl

        headerdata = Public.Httpheaders
        testdata = Public.deletemembers_databy(str(gadget_id))
        print testdata
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="POST",url=requrl,headers = headerdata,body=json.dumps(testdata))
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        code = res["code"]
        print res
        if code == u"0":
            print u"成功返回"
            status = True
        elif code == u"61410":
            print u"管理员删除他自己"
            status = False
        elif code == u"61303":
            print u"不是管理员，没有删除权限"
            status = False
        else:
            print u"其他错误"
            status = False
        self.assertTrue(status)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
