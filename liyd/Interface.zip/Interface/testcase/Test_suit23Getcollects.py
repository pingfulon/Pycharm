#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json,time
import Public
import websocketclient,websockethub
import unittest

class getcollect(unittest.TestCase):

    def setUp(self):
        self.wsh = websockethub.ws
        self.wsc = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def con_message(self,wsc, message):
        if "get_collects" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            if code == u"0":
                print u"上报成功返回0"
                statush = True
            elif code == u"63400":
                print u"上报失败,错误的请求Data数据格式不对"
                statush = False
            elif code == u"63404":
                print u"上报失败servicekey不存在"
                statush = False
            elif code == u"65404":
                print u"失败,错误的请求,歌单id不存在"
                statush = False
            else:
                print u"其他错误"
                statush = False
            self.assertTrue(statush)
            result = "true"
        else:
            result = "false"
        return result

    def hon_message(self, wsh, message):

        if "get_collects" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            if code == u"0":
                print u"上报成功返回0"
                statush = True
            elif code == u"63400":
                print u"上报失败,错误的请求Data数据格式不对"
                statush = False
            elif code == u"63404":
                print u"上报失败service_key不存在"
                statush = False
            else:
                print u"其他错误"
                statush = False
            self.assertTrue(statush)
            result = "true"
        else:
            result = "false"
        return result

    def test_HGetcollect(self):
        #*****************************************设置hub信息*********************************************

        Public.binding()
        wsh = self.wsh
        testdata = Public.getcollects_databy
        print testdata
        wsh.send(json.dumps(testdata))
        for i in range(15):
            message = wsh.recv()
            result = self.hon_message(wsh, message)
            if result == "true":
                statush = True
                break
            else:
                statush = False
                continue

        self.assertTrue(statush)

    def test_CGetcollect(self):
        #*****************************************设置hub信息*********************************************

        Public.binding()
        wsc = self.wsc
        testdata = Public.getcollects_databy

        wsc.send(json.dumps(testdata))
        for i in range(15):
            message = wsc.recv()
            result = self.con_message(wsc, message)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue
        self.assertTrue(statusc)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
