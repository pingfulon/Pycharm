#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
import httpclient
from Data import *

user_id= httpclient.user_id
class advertisement(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/advert?ts=11111"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Advertisement(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        requrl = self.requrl
        headerdata = Public.Httpheaders
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="GET",url=requrl,headers = headerdata)
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        code = res["code"]
        print res

        if code == u"0":
            print u"正常"
            statu = True
        elif code == u"304":
            print u"没有新数据"
            statu = True
        else:
            print u"其他错误"
            statu = False
        self.assertTrue(statu)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
