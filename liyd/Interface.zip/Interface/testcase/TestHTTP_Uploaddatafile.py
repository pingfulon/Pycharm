#! /usr/python/bin
# -*- coding=UTF-8 -*-

import unittest

import requests

import Public
from Data import *


class uploaddatafile(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/datafile/upload"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Uploadfile(self):
        #*******************************************获取hub信息************************************************
        u"""获取hub信息"""
        requrl = self.requrl
        headerdata = Public.Httpheaders
        uploaddatafile_databy = {
            "filename": open("D:/script/python/Interface/testcase/user.txt", "rb")
        }
        #files = Public.uploaddatafile_databy

        res = requests.post( url=requrl, files=uploaddatafile_databy,headers = headerdata)
        print res.status_code
        result = res.json()
        print result
        code = result["code"]
        self.assertEqual(code,u"0")

def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
