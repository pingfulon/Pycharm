#! /usr/python/bin
# -*- coding=UTF-8 -*-

import unittest

import requests

import Public
from Data import *


class hublogupload(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/hub_log/upload"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Hublogupload(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        requrl = self.requrl

        headerdata = Public.hublogupload_header
        uploaddatafile_databy = {
            "filename": open("D:/script/python/Interface/testcase/user.txt", "rb")
        }
        #testdata = Public.uploaddatafile_databy
        res = requests.post(url=requrl,headers = headerdata,files=uploaddatafile_databy)

        print res.status_code
        result = res.json()
        print result

        code = result["code"]
        print res
        if code == u"0":
            print u"成功返回0"
            status = True
        elif code == u"1":
            print u"文件大小超出限制返回1 "
            status = True
        else:
            print u"其他错误"
            status = False
        self.assertTrue(status)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
