#!/usr/bin/python
# -*- coding:UTF-8 -*-

import websockethub,websocketclient
import json,unittest
import Public
import time
from creategadget import gadget_id

class gadgetcreategadget(unittest.TestCase):

    def setUp(self):
        self.wsh = websockethub.ws
        self.wsc = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsc, message):

        # print "hub %s" % message
        if "create_gadget" in message:
            Websocketresh = json.loads(message)
            create_gadget = Websocketresh["msg_type"]
            self.assertEqual(create_gadget,u"create_gadget")
            result = "true"

        else:
            result = "false"

        return result

    def test_Gcreatedgadget(self):
        wsc = self.wsc
        wsh = self.wsh

        testbody = Public.gadgetcreategadget_databy(str(gadget_id))
        wsh.send(json.dumps(testbody))

        for i in range(15):
            message = wsc.recv()
            #print u"sssssssmessage %s" % message

            result = self.on_message(wsc, message)
            #print u"result %s " % result

            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)

        #print result
    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()

if __name__ == "__main__":
    unittest.main()
