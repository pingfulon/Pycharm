#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json, time
#time.sleep(2)
import Public
import websocketclient, websockethub
import unittest


class uploadservicestatus(unittest.TestCase):
    def setUp(self):
        self.wsh = websockethub.ws
        self.wsc = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def con_message(self,wsc, message):
        #print "hub %s" % message
        if "update_service_status" in message:
            Websocketresh = json.loads(message)
            update_service_status = Websocketresh["msg_type"]
            self.assertEqual(update_service_status,u"update_service_status")
            result = "true"

        else:
            result = "false"

        return result

    def hon_message(self,wsh, message):
        #print "hub %s" % message
        if "update_service_status" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            if code == u"0":
                print u"成功返回0"
                status = True
            elif code == u"63404":
                print u"上报失败 service_key 不存在"
                status = False
            else:
                print u"其他错误"
                status = False

            self.assertTrue(status)
            result = "true"

        else:
            result = "false"

        return result
    def test_Uservicestatus(self):
        # *****************************************设置hub信息*********************************************
        u"""设置hub信息"""

        wsh = self.wsh
        wsc = self.wsc
        testdata = Public.uploadservicestatus_databy
        wsh.send(json.dumps(testdata))
        for i in range(15):
            message = wsh.recv()
            #print u"hhhhhhmessage %s" % message

            result = self.hon_message(wsh, message)
            #print u"result %s " % result
            #time.sleep(2)
            if result == "true":
                statush = True
                break
            else:
                statush = False
                continue

        self.assertTrue(statush)

        for i in range(15):
            message = wsc.recv()
            print u"cccccccmessage %s" % message

            result = self.con_message(wsc, message)
            print u"result %s " % result

            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()

if __name__ == "__main__":
    unittest.main()