#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest
import zlib

import Public
import httpclient
from Data import *

user_id= httpclient.user_id
class downloadgadgetzip(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/gadgetzip/download"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Dgadgetzip(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        requrl = self.requrl

        headerdata = Public.Httpheaders
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="GET",url=requrl,headers = headerdata)
        response = conn.getresponse()
        print response.status
        #获取数据
        res= response.read()
        #print res

        result = zlib.decompress(res,16+zlib.MAX_WBITS)
        resultres = json.loads(result)
        #print resultres
        code = resultres["code"]
        self.assertEqual(code,u"0")

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
