#!/user/python/bin
# -*- coding=UTF-8 -*-


import json
import websockethub
import unittest
import Public
import time


class hubupdatafirmwareversion(unittest.TestCase):

    def setUp(self):
        self.ws = websockethub.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsh, message):
        # print "hub %s" % message
        if "hub_update_firmware" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            self.assertEqual(code, u"0")
            result = "true"

        else:
            result = "false"

        return result

    def test_Hupdateversion(self):
        u"""Hub 更新firmware版本号"""
        wsh = self.ws
        bodydata = Public.hufv_databy
        time.sleep(2)
        print bodydata
        wsh.send(json.dumps(bodydata))
        for i in range(15):
            message = wsh.recv()
            #print u"ssssmessage %s" % message

            result = self.on_message(wsh, message)
            #print u"result %s " % result
            time.sleep(2)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()