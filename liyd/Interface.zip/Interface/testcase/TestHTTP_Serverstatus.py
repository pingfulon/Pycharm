#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import unittest

import Public
from Data import *


class serverstatus(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/server/status"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Serverstatus(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        requrl = self.requrl

        headerdata = Public.Httpheaders
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="GET", url=requrl, headers=headerdata)
        response = conn.getresponse()
        print response.status
        # 获取数据
        res = response.read()
        print res
        if res == "100":
            print u"接受转发返回"
            status = True

        elif res == "500":
            print u"暂停转发返回"
            status = True
        else:
            print u"错误"
            status = False
        self.assertTrue(status)
    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
