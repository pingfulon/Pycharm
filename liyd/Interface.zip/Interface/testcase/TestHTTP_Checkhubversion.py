#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
import httpclient
from Data import *

user_id= httpclient.user_id
class checkhubversion(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://" + domain + "/v2.0/check_hub_version/"+ str(Public.hub_id)
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Chubversion(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        requrl = self.requrl

        headerdata = Public.Httpheaders
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="GET",url=requrl,headers = headerdata)
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        code = res["code"]
        print res
        if code == u"0":
            print u"请求成功有更新"
            status = True
        elif code == u"304":
            print u"请求成功无更新"
            status = True
        elif code == u"42004":
            print u"失败：Hub 不存在"
            status = False
        else:
            print u"其他错误"
            status = False
        self.assertTrue(status)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
