#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest
import Public
from Data import *

class setcounteysyncdata(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://"+domain+"/v2.0/user/set_country_sync_data"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_setcounteysyncdata(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        requrl = self.requrl

        headerdata = Public.Httpheaders
        testdata = Public.setcountrysyncdata_databy
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="POST",url=requrl,headers = headerdata,body=json.dumps(testdata) )
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        code = res["code"]
        print res
        self.assertEqual(code ,u"0")

    def test_badlenovoidsetcounteysyncdata(self):
        #******************************************修改用户信息******************************************************
        u"""修改用户信息"""
        requrl = self.requrl

        headerdata = Public.Httpheaders
        testdata = Public.badlenovoidsetcountrysyncdata_databy
        conn = httplib.HTTPSConnection(domain)
        conn.request(method="POST",url=requrl,headers = headerdata,body=json.dumps(testdata) )
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        code = res["code"]
        print res
        self.assertEqual(code ,u"40002")

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)


if __name__ == "__main__":
    unittest.main()
