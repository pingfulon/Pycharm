#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json,time
import Public
import websockethub
import unittest

class nluselect(unittest.TestCase):

    def setUp(self):
        self.wsh = websockethub.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self,wsh, message):
        #print "hub %s" % message
        if "nlu_select" in message:
            jsonresult = message.replace("\\", "").replace("\"}}", "}}").replace("\"{", "{")
            Websocketresh = json.loads(jsonresult)
            getresult = Websocketresh["result"]
            self.assertEqual(getresult, u"ok")

            result = "true"

        else:
            result = "false"

        return result

    def test_NLUselect(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""
        Public.binding()
        wsh = self.wsh
        testdata = Public.nluselect_databy()
        print testdata
        wsh.send(json.dumps(testdata, ensure_ascii=False))
        for i in range(15):
            message = wsh.recv()
            print message

            result = self.on_message(wsh, message)
            #print u"result %s " % result
            #time.sleep(5)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.wsc.close()
        #self.wsh.close()

if __name__ == "__main__":
    unittest.main()