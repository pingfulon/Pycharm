#!/user/python/bin
# -*- coding=UTF-8 -*-


import json
import websocketclient
import unittest
import Public
import time


class deletehimalayanhistory(unittest.TestCase):

    def setUp(self):
        self.wsc = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, wsc, message):
        # print "hub %s" % message
        if "delete_himalayan_history" in message:
            Websocketresh = json.loads(message)
            code = Websocketresh["data"]["code"]
            print code
            if code == u"0":
                    result = "true"
            elif code == u"6000":
                result = "false"
                print u"clienthuspeaker请求云端参数错误"
            elif code == u"6001":
                result = "false"
                print u"访问喜马拉雅云端返回错误"
            elif code == u"6002":
                result = "false"
                print u"访问喜马拉雅云端网络异常"
            elif code == u"6003":
                result = "false"
                print u"lenovo用户下没有授权的喜马拉雅账号"
            elif code == u"6004":
                result = "false"
                print u"喜马拉雅access_token刷新失败"
            self.assertEqual(result , "true")


        else:
            result = "false"

        return result

    def test_hubdeletehimalayanhistory(self):
        u"""Hub 更新firmware版本号"""
        wsc = self.wsc
        bodydata = Public.deletehimalayanhistory_databy
        time.sleep(2)
        print bodydata
        wsc.send(json.dumps(bodydata))
        for i in range(15):
            message = wsc.recv()
            print  message

            result = self.on_message(wsc, message)
            print u"result %s " % result
            time.sleep(2)
            if result == "true":
                statush = True
                break
            else:
                statush = False
                continue

        self.assertTrue(statush)

    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()