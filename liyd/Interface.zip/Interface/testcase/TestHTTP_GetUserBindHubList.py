#! /usr/python/bin
# -*- coding=UTF-8 -*-

import httplib
import json
import unittest

import Public
from Data import *


class getuserbindhublist(unittest.TestCase):

    def setUp(self):
        self.requrl = "https://"+domain+"/v2.0/hubs?ts=11111"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Guserbindhublist(self):
        #****************************************获取用户已绑定的 Hub列表***************************************
        u"""获取用户已绑定的 Hub列表"""
        requrl = self.requrl

        headerdata = Public.Httpheaders

        conn = httplib.HTTPSConnection(domain)
        conn.request(method="GET",url=requrl,headers = headerdata)
        response = conn.getresponse()

        #获取数据
        res= json.loads(response.read())
        print res
        code = res["code"]
        hubs = res["hubs"]
        if code == "0" and hubs != []:
            statu = True
        elif code == "304":
            statu = True
            print u"请求成功，没有新数据"
        elif code == "0" and hubs == []:
            statu = True
        else:
            statu = False

        self.assertTrue(statu)



    def tearDown(self):
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()


