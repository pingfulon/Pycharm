#! /usr/python/bin
# -*- coding=UTF-8 -*-
import json
import time
import unittest

import Public
import websocketclient


class minihubactivate(unittest.TestCase):

    def setUp(self):
        self.ws = websocketclient.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_Mhubactivate(self):
        #*****************************************设置hub信息*********************************************
        u"""设置hub信息"""
        ws = self.ws
        testdata = Public.minihubactivate_databy
        ws.send(json.dumps(testdata))
        time.sleep(15)
        result = json.loads(ws.recv())
        print "result %s" %result
        code = result["data"]["code"]
        if code == u"0" :
            print  "此 Hub被用户（client）绑定后的首次激活"
            status = True
        elif code == u"42000":
            print "此 Hub被用户（client）绑定后的非首次激活"
            status = True
        elif code == u"42002":
            print "此 Hub没有被用户（client）绑定"
            status = False
        elif code == u"50104":
            print "HubTyp不存在"
            status = False
        elif code == u"42003":
            print "Key校验失败"
            status = False

        self.assertTrue(status)


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.ws.close()

if __name__ == "__main__":
    unittest.main()