#!/user/python/bin
# -*- coding=UTF-8 -*-
#unicode

import json,httplib
import websockethub
import Public
import time
import unittest


class Hubisbindbinded(unittest.TestCase):

    def setUp(self):
        self.ws = websockethub.ws
        self.verificationErrors = []
        self.accept_next_alert = True

    def on_message(self, ws, message):
        if "hub_is_binded" in message:
            Websocketresh = json.loads(message)
            result = "true"

        else:
            result = "fales"

        return result

    def test_Hisbinded(self):
        hub_id = []
        hubinfo = Public.gethublist()
        code = hubinfo["code"]
        hub = hubinfo["hubs"]

        if code == u"0":
            if hub == []:
                #Public.binding()
                print u"hub未绑定"
            else:
                print u"hub已绑定"
                for i in range(0, len(hub)):
                    print i
                    hub_ids = hubinfo["hubs"][0]["hub_id"]
                    hub_id.append(hub_ids)
                    code = Public.unbind(hub_ids)
                    hubinfo = Public.gethublist()
                    print hubinfo

                print u"hub解绑成功"
            Public.binding()
            hubinfo = Public.gethublist()
            print hubinfo
        else:
            print u"hub不存在或没有权限操作此hub"

        wsh = self.ws

        for i in range(15):

            message = wsh.recv()
            print u"message %s" % message

            result = self.on_message(wsh, message)
            print u"result %s " % result
            #time.sleep(2)
            if result == "true":
                statusc = True
                break
            else:
                statusc = False
                continue

        self.assertTrue(statusc)


    def tearDown(self):
        self.assertEqual([], self.verificationErrors)
        #self.ws.close()

if __name__ == "__main__":
    unittest.main()

