#! /usr/python/bin
# -*- coding=UTF-8 -*-

import HTMLTestRunner
import time
import unittest
import sys,json

sys.path.append("D:\\script\\python\\Interface")
sys.path.append("D:\\script\\python\\Interface\\testcase")

a = "aaaaaaa"
caselist = "D:\\script\\python\\Interface\\testcase"
def suite():
    testunit = unittest.TestSuite()
    # discover 方法定义
    discover = unittest.defaultTestLoader.discover(caselist,
                                                   pattern='TestHTTP_*.py',
                                                   top_level_dir=None)
    for testsuit in discover:

        for testcase in testsuit:
            testunit.addTest(testcase)
    return testunit

#取前面时间
now = time.strftime("%Y-%m-%M_%H_%M_%S",time.localtime(time.time()))

#定义个报告存放路径，支持相对路径。
filename = "D:\\script\\python\\Interface\\Report\\"+now+"httpresult.html"

fp = file(filename, 'wb')
runner =HTMLTestRunner.HTMLTestRunner(
    stream=fp,
    title=u"Interface测试报告",
    description=u"用例执行情况：")

alltestname = suite()

runner.run(alltestname)